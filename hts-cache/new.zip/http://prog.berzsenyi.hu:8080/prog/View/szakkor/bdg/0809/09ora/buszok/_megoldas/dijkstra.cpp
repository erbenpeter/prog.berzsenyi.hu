<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp">dijkstra.cpp</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_selected">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2868';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2962';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3009';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=3063';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3126';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3213';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3235';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3313';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3353';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3373';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3415';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=3459';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3492';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3527';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3623';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3662';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3715';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3741';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3764';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3782';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=3800';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3813';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3880';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3901';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3933';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=3934';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=3957';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=3951';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=3958';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=3959';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/09ora">9. óra - Dijsktra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2868">1. óra - Ismétléses variáció</option><option  value="2962">2. óra - Permutáció</option><option  value="3009">3. óra</option><option  value="3063">4. óra</option><option  value="3126">5. óra - Kombináció</option><option  value="3213">6. óra - Partíció</option><option  value="3235">7. óra - Halmaz-partíció</option><option  value="3313">8. óra - Floyd-Warshall algoritmus</option><option  selected="selected"  value="3353">9. óra - Dijsktra</option><option  value="3373">10. óra - Szélességi és mélységi bejárás</option><option  value="3415">11. óra</option><option  value="3459">12. óra</option><option  value="3492">13. óra</option><option  value="3527">14. óra</option><option  value="3623">15. óra</option><option  value="3662">16. óra</option><option  value="3715">17. óra</option><option  value="3741">18. óra</option><option  value="3764">19. óra</option><option  value="3782">20. óra</option><option  value="3800">21. óra</option><option  value="3813">22. óra</option><option  value="3880">25. óra</option><option  value="3901">26. óra</option><option  value="3933">27. óra</option><option  value="3934">28. óra</option><option  value="3957">29. óra</option><option  value="3951">30. óra - Kifejezés kiértékelés</option><option  value="3958">31. óra</option><option  value="3959">32. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 30) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=3663';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=3223';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3354';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2869';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3805';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3460';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3128';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3374';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3783';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3814';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3493';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2963';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3801';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3816';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3815';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3765';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3010';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3314';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3236';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3416';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=106';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3064';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3417';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3461';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3766';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/09ora/buszok">Buszok</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="3663">Apokaliptikus sorrend</option><option  value="3223">Bolgár szoliter</option><option  selected="selected"  value="3354">Buszok</option><option  value="2869">Fej vagy írás</option><option  value="3805">Fuvarozás</option><option  value="3460">Hálózat</option><option  value="3128">Vektorok</option><option  value="3374">Idegenvezetés</option><option  value="3783">Kincsvadász</option><option  value="3814">Konténerek</option><option  value="3493">Labirintus</option><option  value="2963">Langford permutációk</option><option  value="3801">Négyzetek</option><option  value="3816">PC összeszerelés</option><option  value="3815">Pingvinek menetelése</option><option  value="3765">Póker</option><option  value="3010">Számjegyek kitalálása</option><option  value="3314">Szerkezetek</option><option  value="3236">Szigetek</option><option  value="3416">Tagok</option><option  value="106">Terv</option><option  value="3064">Választási rendszerek</option><option  value="3417">Város</option><option  value="3461">Vidámpark</option><option  value="3766">Zárójelek</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 25) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0809/09ora">9. óra - Dijsktra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0809/09ora/buszok">Buszok</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809">2008/2009</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/09ora">9. óra - Dijsktra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/09ora/buszok">Buszok</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp">dijkstra.cpp</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas/dijkstra.cpp">dijkstra.cpp</a>
        
            (<a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="3386" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 4 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.cpp_preproc {
color: purple;
}
.cpp_doxygen_comment {
color: rgb(147,147,147); background-color: rgb(247,247,247);  
}
.cpp_doxygen_tag {
color: rgb(147,147,147); background-color: rgb(247,247,247); font-style: italic; font-weight: bold;
}
.cpp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_user_type {
color: #0095ff;  font-weight: bold;
}
.cpp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.cpp_type {
color: rgb(128,0,0);
}
.cpp_operator {
color: rgb(0,0,0);
}
.cpp_char_literal {
color: rgb(255,0,255);
}
.cpp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.cpp_num_literal {
color: rgb(0,0,255);
}
.cpp_comment {
color: rgb(147,147,147);  
}
.cpp_plain {
color: rgb(0,0,0);
}
.cpp_string_literal {
color: rgb(255,0,0);
}
.cpp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;type&#160;</span><span class="cpp_type">unsigned</span><span class="cpp_plain">&#160;</span><span class="cpp_type">long</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;inf&#160;</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1L</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;MaxNum&#160;</span><span class="cpp_num_literal">10</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;MaxBusN&#160;</span><span class="cpp_num_literal">50</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">stdio</span><span class="cpp_separator">.</span><span class="cpp_plain">h</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;matrix.h&quot;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">/*</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;Dijkstra&#160;algoritmus&#160;alkalmaz&aacute;sa</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;A&#160;programot&#160;Uray&#160;M.&#160;J&aacute;nos&#160;k&eacute;sz&iacute;tette&#160;2008.&#160;november&#160;18-&aacute;n.</span><br /><span class="cpp_comment">*/</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;&ouml;sszes&#160;pont&#160;adata&#160;az&#160;egyikre&#160;n&eacute;zve&#160;a&#160;Dijkstra&#160;algoritmushoz</span><br /><span class="cpp_keyword">struct</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;t&aacute;vols&aacute;g</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;type&#160;D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;k&eacute;k-e,&#160;előző&#160;sorsz&aacute;ma</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;bDone</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Prev</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">MaxNum</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;gr&aacute;f,&#160;&eacute;s&#160;&eacute;leinek&#160;sz&aacute;ma</span><br /><span class="cpp_plain">cMatrix&#160;Graph</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_plain">&#160;Num</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_keyword">struct</span><span class="cpp_plain">&#160;point&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;type&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">};</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;&ouml;sszead&aacute;s&#160;a&#160;v&eacute;gtelennel&#160;kiterjesztve</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;type&#160;add&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">type&#160;A</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;type&#160;B</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">A&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;inf&#160;</span><span class="cpp_operator">||</span><span class="cpp_plain">&#160;B&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;A&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;B</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;</span><span class="cpp_type">long</span><span class="cpp_plain">&#160;abs&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">long</span><span class="cpp_plain">&#160;A</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;A&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">?</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">A&#160;</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;A</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;k&eacute;t&#160;pont&#160;t&aacute;vols&aacute;ga</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;type&#160;Dist&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">point&#160;A</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;B</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;abs</span><span class="cpp_separator">(</span><span class="cpp_plain">A</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;B</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;abs</span><span class="cpp_separator">(</span><span class="cpp_plain">A</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;B</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">type&#160;Dist&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">point</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">type&#160;Dist&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">point</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;Dijkstra&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_plain">&#160;main&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;AN</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;Args&#160;</span><span class="cpp_separator">[])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;L</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;type&#160;D</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;point&#160;P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">2</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;FILE&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;OF</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">struct</span><span class="cpp_plain">&#160;sBus&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;N</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Prise</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;point&#160;P</span><span class="cpp_separator">[</span><span class="cpp_plain">MaxBusN</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;printf</span><span class="cpp_separator">(</span><span class="cpp_string_literal">&quot;&lt;--&#160;Start&#160;--&gt;\n&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">AN&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">3</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;IF&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;fopen</span><span class="cpp_separator">(</span><span class="cpp_plain">Args</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;rt&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">IF&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;NULL</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%ld\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">D</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%ld&#160;%ld\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">].</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">].</span><span class="cpp_plain">Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%ld&#160;%ld\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">].</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">].</span><span class="cpp_plain">Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%d\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">R</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Bus&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">new</span><span class="cpp_plain">&#160;sBus&#160;</span><span class="cpp_separator">[</span><span class="cpp_plain">R</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%d&#160;%d&#160;&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">Prise</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%ld&#160;%ld&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;\n&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fclose</span><span class="cpp_separator">(</span><span class="cpp_plain">IF</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;első&#160;R&#160;cs&uacute;cs&#160;a&#160;buszokat,&#160;az&#160;utols&oacute;&#160;kettő&#160;pedig&#160;a&#160;k&eacute;t&#160;pontot&#160;jelenti</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">Set</span><span class="cpp_separator">(</span><span class="cpp_plain">R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">K&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;K</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_plain">K</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[(</span><span class="cpp_plain">K&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">%</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">]);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">R</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]));</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]));</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;R</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">K&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;K</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">L&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;L&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;L</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_plain">K</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[(</span><span class="cpp_plain">K&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">%</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">],</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[</span><span class="cpp_plain">L</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">P</span><span class="cpp_separator">[(</span><span class="cpp_plain">L&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">%</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">].</span><span class="cpp_plain">N</span><span class="cpp_separator">]);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">SetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Num&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Dijkstra</span><span class="cpp_separator">(</span><span class="cpp_plain">R</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;OF&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;fopen</span><span class="cpp_separator">(</span><span class="cpp_plain">Args</span><span class="cpp_separator">[</span><span class="cpp_num_literal">2</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;wt&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">OF&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;NULL</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">OF</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%ld&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">R&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">].</span><span class="cpp_plain">D</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fclose</span><span class="cpp_separator">(</span><span class="cpp_plain">OF</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">delete</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">[]</span><span class="cpp_plain">&#160;Bus</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;szakasz&#160;&eacute;s&#160;pont&#160;t&aacute;vols&aacute;ga</span><br /><span class="cpp_plain">type&#160;Dist&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">point&#160;S0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;S1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;P</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;f&uuml;ggőleges</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">((</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">||</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">))</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">S0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">((</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">||</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">))</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">S1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;abs</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;v&iacute;zszintes</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">((</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">||</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">))</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">S0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">((</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">||</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">))</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">S1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;P</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;abs</span><span class="cpp_separator">(</span><span class="cpp_plain">P</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;S0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;k&eacute;t&#160;szakasz&#160;t&aacute;vols&aacute;ga</span><br /><span class="cpp_plain">type&#160;Dist&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">point&#160;A0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;A1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;B0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;point&#160;B1</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">A0</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;A1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;A0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;A1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Len:&#160;az&#160;A&#160;szakasz&#160;hossza</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;type&#160;Len&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">A0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;A1</span><span class="cpp_separator">),</span><span class="cpp_plain">&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Step:&#160;az&#160;A&#160;szakaszon&#160;val&oacute;&#160;l&eacute;pked&eacute;s&#160;egys&eacute;ge</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A:&#160;az&#160;A&#160;szakasz&#160;l&eacute;ptet&eacute;s&eacute;nek&#160;aktu&aacute;lis&#160;helye&#160;a&#160;ciklusban</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;point&#160;Step</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;A&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;A0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">long</span><span class="cpp_separator">)(</span><span class="cpp_plain">A1</span><span class="cpp_separator">.</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;A0</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">/</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">long</span><span class="cpp_separator">)</span><span class="cpp_plain">Len</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">long</span><span class="cpp_separator">)(</span><span class="cpp_plain">A1</span><span class="cpp_separator">.</span><span class="cpp_plain">Y&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;A0</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">/</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">long</span><span class="cpp_separator">)</span><span class="cpp_plain">Len</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Dist</span><span class="cpp_separator">(</span><span class="cpp_plain">B0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;B1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;A</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//printf(&quot;(%ld&#160;%ld)&#160;(%ld&#160;%ld)&#160;%ld\n&quot;,&#160;A.X,&#160;A.Y,&#160;Step.X,&#160;Step.Y,&#160;D);</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_operator">+=</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">.</span><span class="cpp_plain">X</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_operator">+=</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">.</span><span class="cpp_plain">Y</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;Dijkstra&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Start</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;N&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Num</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;A</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;type&#160;DD</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Alap&eacute;rt&eacute;kek&#160;be&aacute;ll&iacute;t&aacute;sa.</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Num</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">bDone&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">Prev&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">Start</span><span class="cpp_separator">].</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0L</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">while</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">N</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Minimumkiv&aacute;laszt&aacute;s,&#160;majd&#160;k&eacute;kbe&#160;tev&eacute;s</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;inf</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Num</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_operator">!</span><span class="cpp_plain">S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">bDone&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Min</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Min&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">D</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">A</span><span class="cpp_separator">].</span><span class="cpp_plain">bDone&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;N</span><span class="cpp_operator">--</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;&Ouml;sszehasonl&iacute;t&aacute;s&#160;a&#160;szomsz&eacute;dosakkal</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Num</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_operator">!</span><span class="cpp_plain">S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">bDone</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;DD&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;add</span><span class="cpp_separator">(</span><span class="cpp_plain">S</span><span class="cpp_separator">[</span><span class="cpp_plain">A</span><span class="cpp_separator">].</span><span class="cpp_plain">D</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Graph</span><span class="cpp_separator">.</span><span class="cpp_plain">GetItem</span><span class="cpp_separator">(</span><span class="cpp_plain">A</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">));</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">DD&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">D</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">D&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;DD</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">].</span><span class="cpp_plain">Prev&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;A</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0809/09ora/buszok/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:23:22
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
