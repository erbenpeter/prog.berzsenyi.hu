<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp">mb_gomb.cpp</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_selected">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=5169';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=5273';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=5322';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=5356';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=5366';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=5378';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=5402';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5417';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=5462';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=5489';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=5501';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5521';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=5525';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=5536';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=5541';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=5577';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=5593';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=5604';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=5617';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=5670';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=5672';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=5696';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=5714';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=5728';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=5779';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5821';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5824';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5830';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/1011/05ora">5. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="5169">1. óra</option><option  value="5273">2. óra</option><option  value="5322">3. óra</option><option  value="5356">4. óra</option><option  selected="selected"  value="5366">5. óra</option><option  value="5378">6. óra</option><option  value="5402">7. óra</option><option  value="5417">8. óra</option><option  value="5462">9. óra</option><option  value="5489">10. óra</option><option  value="5501">11. óra</option><option  value="5521">12. óra</option><option  value="5525">13. óra</option><option  value="5536">14. óra</option><option  value="5541">15. óra</option><option  value="5577">16. óra</option><option  value="5593">17. óra</option><option  value="5604">18. óra</option><option  value="5617">19. óra</option><option  value="5670">20. óra</option><option  value="5672">21. óra</option><option  value="5696">22. óra</option><option  value="5714">23. óra</option><option  value="5728">24. óra</option><option  value="5779">25. óra</option><option  value="5821">26. óra</option><option  value="5824">27. óra</option><option  value="5830">28. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 28) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=5490';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=5526';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=5729';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=5334';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=5388';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=5697';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=5679';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5578';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=5505';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=5543';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=5279';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5618';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=5542';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=5605';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=5546';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=5677';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=5678';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=5468';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=5715';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=5463';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=5212';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=5357';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=5545';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=5673';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=5367';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5706';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5676';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5544';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=5734';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=5598';
        }
        if (selObj.selectedIndex == 31) {
            window.location = '/prog/Resolve?node=5831';
        }
        if (selObj.selectedIndex == 32) {
            window.location = '/prog/Resolve?node=5404';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/1011/05ora/pe222">Gömbök</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="5490">Anagramma</option><option  value="5526">Baktériumok</option><option  value="5729">Befektetés</option><option  value="5334">Collatz-sorozat</option><option  value="5388">Csokoládés keksz</option><option  value="5697">Csomózás</option><option  value="5679">Csoport beosztás_2011</option><option  value="5578">Dominó forgatás</option><option  value="5505">Elegáns gyémántok</option><option  value="5543">Fa</option><option  value="5279">Becsületes figyelmeztetés</option><option  value="5618">Fák izomorfiája</option><option  value="5542">Falvak</option><option  value="5605">Hurkok</option><option  value="5546">Játék</option><option  value="5677">Kemence_2011</option><option  value="5678">Képzés_2011</option><option  value="5468">Fűrészmalom</option><option  value="5715">Legnagyobb üres téglalap</option><option  value="5463">Shakespeare</option><option  value="5212">Nagy számok összege</option><option  value="5357">Osztás nagy számokkal</option><option  value="5545">Pakolás</option><option  value="5673">Párok_2011</option><option  selected="selected"  value="5367">Gömbök</option><option  value="5706">Pecsételő</option><option  value="5676">Sudoku_2011</option><option  value="5544">Takar</option><option  value="5734">Városnézés</option><option  value="5598">VB2010</option><option  value="5831">Repülőtéri futószalagok</option><option  value="5404">Fehér cella</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 32) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/1011/05ora">5. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/1011/05ora/pe222">Gömbök</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011">2010/2011</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/05ora">5. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/05ora/pe222">Gömbök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp">mb_gomb.cpp</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas/mb_gomb.cpp">mb_gomb.cpp</a>
        
            (<a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="5381" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: us-ascii</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: us-ascii <br />
        
        Méret: 1 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.cpp_preproc {
color: purple;
}
.cpp_doxygen_comment {
color: rgb(147,147,147); background-color: rgb(247,247,247);  
}
.cpp_doxygen_tag {
color: rgb(147,147,147); background-color: rgb(247,247,247); font-style: italic; font-weight: bold;
}
.cpp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_user_type {
color: #0095ff;  font-weight: bold;
}
.cpp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.cpp_type {
color: rgb(128,0,0);
}
.cpp_operator {
color: rgb(0,0,0);
}
.cpp_char_literal {
color: rgb(255,0,255);
}
.cpp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.cpp_num_literal {
color: rgb(0,0,255);
}
.cpp_comment {
color: rgb(147,147,147);  
}
.cpp_plain {
color: rgb(0,0,0);
}
.cpp_string_literal {
color: rgb(255,0,0);
}
.cpp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">cstdio</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">math</span><span class="cpp_separator">.</span><span class="cpp_plain">h</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">iostream</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">algorithm</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_keyword">using</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">namespace</span><span class="cpp_plain">&#160;std</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">float</span><span class="cpp_plain">&#160;calcheight</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_operator">*</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;next_order</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_type">bool</span><span class="cpp_plain">&#160;compare</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_plain">&#160;n</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;r</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;ro</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_plain">&#160;main</span><span class="cpp_separator">()</span><span class="cpp_plain"></span><br /><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;n&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">21</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">new</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">[</span><span class="cpp_plain">n</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">new</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">[</span><span class="cpp_plain">n</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">30</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">31</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">2</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">32</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">3</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">33</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">4</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">34</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">5</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">35</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">6</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">36</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">7</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">37</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">8</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">38</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">9</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">39</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">10</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">40</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">11</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">41</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">12</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">42</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">13</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">43</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">14</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">44</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">15</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">45</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">16</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">46</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">17</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">47</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">18</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">48</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">19</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">49</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;r</span><span class="cpp_separator">[</span><span class="cpp_num_literal">20</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">50</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">19</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">17</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">2</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">15</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">3</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">13</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">4</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">11</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">5</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">9</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">6</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">7</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">7</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">5</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">8</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">3</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">9</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">10</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">11</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">12</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">4</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">13</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">6</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">14</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">8</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">15</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">10</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">16</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">12</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">17</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">14</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">18</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">16</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">19</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">18</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">20</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">20</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">/*sort(ro,&#160;ro+n,&#160;compare);</span><br /><span class="cpp_comment"></span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;while(true)</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;{</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;printf(&quot;O:&#160;%d&#160;%d&#160;%d&#160;%d&#160;%d\n&quot;,&#160;r[ro[0]],&#160;r[ro[1]],&#160;r[ro[2]],&#160;r[ro[3]],&#160;r[ro[4]]);</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;printf(&quot;H:&#160;%f\n&quot;,&#160;calcheight(r));</span><br /><span class="cpp_comment"></span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;next_order();</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cin.get();</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;}*/</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;printf</span><span class="cpp_separator">(</span><span class="cpp_string_literal">&quot;H:&#160;%f\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1000</span><span class="cpp_operator">*</span><span class="cpp_plain">calcheight</span><span class="cpp_separator">(</span><span class="cpp_plain">r</span><span class="cpp_separator">));</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;cin</span><span class="cpp_separator">.</span><span class="cpp_plain">get</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">float</span><span class="cpp_plain">&#160;calcheight</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;r</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">float</span><span class="cpp_plain">&#160;h</span><span class="cpp_operator">=</span><span class="cpp_plain">r</span><span class="cpp_separator">[</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_num_literal">0</span><span class="cpp_separator">]];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">=</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">n</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;h</span><span class="cpp_operator">+=</span><span class="cpp_num_literal">10</span><span class="cpp_operator">*</span><span class="cpp_plain">sqrt</span><span class="cpp_separator">(</span><span class="cpp_num_literal">2</span><span class="cpp_operator">*</span><span class="cpp_plain">r</span><span class="cpp_separator">[</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_separator">]]</span><span class="cpp_operator">+</span><span class="cpp_num_literal">2</span><span class="cpp_operator">*</span><span class="cpp_plain">r</span><span class="cpp_separator">[</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_operator">+</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]]</span><span class="cpp_operator">-</span><span class="cpp_num_literal">100</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;h</span><span class="cpp_operator">+=</span><span class="cpp_plain">r</span><span class="cpp_separator">[</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">n</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]];</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;h</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">bool</span><span class="cpp_plain">&#160;compare</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;p1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;p2</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;p1</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">p2</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;next_order</span><span class="cpp_separator">()</span><span class="cpp_plain"></span><br /><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;done</span><span class="cpp_operator">=</span><span class="cpp_bool_literal">false</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">=</span><span class="cpp_plain">n</span><span class="cpp_operator">-</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">&gt;=</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">!</span><span class="cpp_plain">done</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;i</span><span class="cpp_operator">--</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_separator">(</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_operator">+</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_separator">])</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;ind</span><span class="cpp_operator">=</span><span class="cpp_plain">i</span><span class="cpp_operator">+</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;j</span><span class="cpp_operator">=</span><span class="cpp_plain">i</span><span class="cpp_operator">+</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;j</span><span class="cpp_operator">&lt;=</span><span class="cpp_plain">n</span><span class="cpp_operator">-</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;j</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_separator">(</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">j</span><span class="cpp_separator">]</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_plain">j</span><span class="cpp_separator">]</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">ind</span><span class="cpp_separator">])</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ind</span><span class="cpp_operator">=</span><span class="cpp_plain">j</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;v</span><span class="cpp_operator">=</span><span class="cpp_plain">ro</span><span class="cpp_separator">[</span><span class="cpp_plain">ind</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_plain">ind</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sort</span><span class="cpp_separator">(</span><span class="cpp_plain">ro</span><span class="cpp_operator">+</span><span class="cpp_plain">i</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;ro</span><span class="cpp_operator">+</span><span class="cpp_plain">n</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;compare</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ro</span><span class="cpp_separator">[</span><span class="cpp_plain">i</span><span class="cpp_separator">]</span><span class="cpp_operator">=</span><span class="cpp_plain">v</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;done</span><span class="cpp_operator">=</span><span class="cpp_bool_literal">true</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/1011/05ora/pe222/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2010-10-18 17:14:40
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
