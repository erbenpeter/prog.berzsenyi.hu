<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs">labirintus.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_selected">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2868';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2962';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3009';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=3063';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3126';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3213';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3235';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3313';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3353';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3373';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3415';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=3459';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3492';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3527';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3623';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3662';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3715';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3741';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3764';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3782';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=3800';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3813';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3880';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3901';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3933';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=3934';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=3957';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=3951';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=3958';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=3959';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/13ora">13. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2868">1. óra - Ismétléses variáció</option><option  value="2962">2. óra - Permutáció</option><option  value="3009">3. óra</option><option  value="3063">4. óra</option><option  value="3126">5. óra - Kombináció</option><option  value="3213">6. óra - Partíció</option><option  value="3235">7. óra - Halmaz-partíció</option><option  value="3313">8. óra - Floyd-Warshall algoritmus</option><option  value="3353">9. óra - Dijsktra</option><option  value="3373">10. óra - Szélességi és mélységi bejárás</option><option  value="3415">11. óra</option><option  value="3459">12. óra</option><option  selected="selected"  value="3492">13. óra</option><option  value="3527">14. óra</option><option  value="3623">15. óra</option><option  value="3662">16. óra</option><option  value="3715">17. óra</option><option  value="3741">18. óra</option><option  value="3764">19. óra</option><option  value="3782">20. óra</option><option  value="3800">21. óra</option><option  value="3813">22. óra</option><option  value="3880">25. óra</option><option  value="3901">26. óra</option><option  value="3933">27. óra</option><option  value="3934">28. óra</option><option  value="3957">29. óra</option><option  value="3951">30. óra - Kifejezés kiértékelés</option><option  value="3958">31. óra</option><option  value="3959">32. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 30) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=3663';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=3223';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3354';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2869';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3805';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3460';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3128';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3374';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3783';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3814';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3493';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2963';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3801';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3816';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3815';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3765';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3010';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3314';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3236';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3416';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=106';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3064';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3417';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3461';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3766';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/13ora/labirintus">Labirintus</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="3663">Apokaliptikus sorrend</option><option  value="3223">Bolgár szoliter</option><option  value="3354">Buszok</option><option  value="2869">Fej vagy írás</option><option  value="3805">Fuvarozás</option><option  value="3460">Hálózat</option><option  value="3128">Vektorok</option><option  value="3374">Idegenvezetés</option><option  value="3783">Kincsvadász</option><option  value="3814">Konténerek</option><option  selected="selected"  value="3493">Labirintus</option><option  value="2963">Langford permutációk</option><option  value="3801">Négyzetek</option><option  value="3816">PC összeszerelés</option><option  value="3815">Pingvinek menetelése</option><option  value="3765">Póker</option><option  value="3010">Számjegyek kitalálása</option><option  value="3314">Szerkezetek</option><option  value="3236">Szigetek</option><option  value="3416">Tagok</option><option  value="106">Terv</option><option  value="3064">Választási rendszerek</option><option  value="3417">Város</option><option  value="3461">Vidámpark</option><option  value="3766">Zárójelek</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 25) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0809/13ora">13. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus">Labirintus</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809">2008/2009</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/13ora">13. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus">Labirintus</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs">labirintus.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas/labirintus.cs">labirintus.cs</a>
        
            (<a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="3522" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 5 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_plain">﻿</span><span class="csharp_comment">/*</span><br /><span class="csharp_comment">﻿&#160;*&#160;A&#160;http://prog.berzsenyi.hu:8080/prog/View/szakkor/bdg/0809/13ora/labirintus&#160;oldalon&#160;tal&aacute;lhat&oacute;&#160;Labirintus&#160;probl&eacute;ma&#160;megold&aacute;sa.</span><br /><span class="csharp_comment">﻿&#160;*&#160;&Iacute;rta:&#160;Kriv&aacute;n&#160;B&aacute;lint,&#160;szakk&ouml;ri&#160;megbesz&eacute;l&eacute;s&#160;alapj&aacute;n&#160;(2008.&#160;dec.&#160;16-17.)</span><br /><span class="csharp_comment">﻿&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">IO</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">Collections</span><span class="csharp_separator">.</span><span class="csharp_plain">Generic</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;Labyrinth</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">struct</span><span class="csharp_plain">&#160;Coords</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">z</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Coords</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;z1&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;x&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;x1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;y&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;y1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;z&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;z1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_comment">/**</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;*&#160;A&#160;labirintus&#160;adott&#160;mezeje.</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Mezo</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">/*&#160;</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;0-&uuml;res</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;1-fal&#160;(ezek&#160;k&ouml;z&ouml;tt&#160;van&#160;ajt&oacute;&#160;is,&#160;de&#160;egy&#160;dimenzi&oacute;ban&#160;mindig&#160;z&aacute;rt!)</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;2-kapcsol&oacute;</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;v</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">/**</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*&#160;L&eacute;p&eacute;ssz&aacute;m,&#160;alapb&oacute;l&#160;-1,&#160;azaz&#160;m&eacute;g&#160;sose&#160;j&aacute;rtunk&#160;ott</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;step&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Labyrinth</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;n</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Mezo</span><span class="csharp_separator">[,,]</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Queue</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">Coords</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;q&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Queue</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">Coords</span><span class="csharp_operator">&gt;</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;input</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Labyrinth</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;input</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">input&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;input</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;StreamReader&#160;ins&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamReader</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;labi.be&quot;</span><span class="csharp_operator">+</span><span class="csharp_plain">input</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;line&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;ins</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">line</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;n&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">line</span><span class="csharp_separator">[</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Mezo</span><span class="csharp_separator">[</span><span class="csharp_plain">n</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">2</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">byte</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">m</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;line&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;ins</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">n</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">++</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;c&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">byte</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;line</span><span class="csharp_separator">[</span><span class="csharp_plain">j</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Mezo</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Mezo</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">3</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">4</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;solve</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">/**</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*&#160;L&eacute;p&#160;az&#160;adott&#160;(x,y,z)-ről&#160;(dx,dy)&#160;vektor&#160;ir&aacute;ny&aacute;ba.&#160;Ha&#160;lehet,&#160;akkor&#160;elt&aacute;roljuk&#160;a&#160;sorban&#160;a&#160;l&eacute;p&eacute;st,&#160;ha&#160;nem&#160;akkor&#160;semmi&#160;sem&#160;t&ouml;rt&eacute;nik.</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;step</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;dy&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;prevStep&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">z</span><span class="csharp_separator">].</span><span class="csharp_plain">step</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//dimenzi&oacute;t&#160;ment&uuml;nk</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;n&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;m&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;ha&#160;minden&#160;koordin&aacute;ta&#160;rendben&#160;van</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">!=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;ha&#160;nem&#160;falra&#160;szeret&eacute;nk&#160;l&eacute;pni</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">2</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;ha,&#160;ahova&#160;l&eacute;p&uuml;nk,&#160;ott&#160;kapcsol&oacute;&#160;van,&#160;akkor&#160;dimenzi&oacute;&#160;v&aacute;lt&aacute;s!</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;z&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Abs</span><span class="csharp_separator">(</span><span class="csharp_num_literal">1</span><span class="csharp_operator">-</span><span class="csharp_plain">z</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;ha&#160;oda&#160;l&eacute;p&uuml;nk,&#160;ahol&#160;m&eacute;g&#160;nem&#160;j&aacute;rtunk</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;l&eacute;p&eacute;ssz&aacute;mot&#160;be&aacute;ll&iacute;tjuk</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;prevStep</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;sorba&#160;betesz</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;q</span><span class="csharp_separator">.</span><span class="csharp_plain">Enqueue</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Coords</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">/**</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*&#160;Az&#160;adott&#160;(x,y,z)&#160;pontr&oacute;l&#160;ell&eacute;p&#160;(dx,dy)&#160;vektorral,&#160;ha&#160;lehets&eacute;ges.</span><br /><span class="csharp_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">bool</span><span class="csharp_plain">&#160;stepBack</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;dy&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;n&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;m&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;prevZ&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">2</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;prevZ&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Abs</span><span class="csharp_separator">(</span><span class="csharp_plain">prevZ-1</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;ha&#160;egy&#160;kapcsol&oacute;&#160;az&#160;őse,&#160;akkor&#160;annak&#160;az&#160;előző&#160;dimenzi&oacute;ban&#160;kell&#160;lennie.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_operator">+</span><span class="csharp_plain">dx</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_operator">+</span><span class="csharp_plain">dy</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;prevZ</span><span class="csharp_separator">].</span><span class="csharp_plain">step-1&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;x&#160;</span><span class="csharp_operator">+=</span><span class="csharp_plain">&#160;dx</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;y&#160;</span><span class="csharp_operator">+=</span><span class="csharp_plain">&#160;dy</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">].</span><span class="csharp_plain">v&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">2</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Abs</span><span class="csharp_separator">(</span><span class="csharp_plain">z-1</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">false</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;solve</span><span class="csharp_separator">()</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;sz&eacute;less&eacute;gi&#160;bej&aacute;r&aacute;st&#160;tolunk,&#160;kezdő&#160;a&#160;(0,0,0).</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;q</span><span class="csharp_separator">.</span><span class="csharp_plain">Enqueue</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Coords</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;table</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_num_literal">0</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;be&aacute;ll&iacute;tjuk&#160;az&#160;itten&#160;l&eacute;p&eacute;ssz&aacute;mot&#160;0-ra.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Coords&#160;c</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">while</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;q</span><span class="csharp_separator">.</span><span class="csharp_plain">Count&#160;</span><span class="csharp_operator">!=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;c&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;q</span><span class="csharp_separator">.</span><span class="csharp_plain">Dequeue</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;minden&#160;szomsz&eacute;dot&#160;checkolunk,&#160;ha&#160;l&eacute;phet&uuml;nk&#160;oda,&#160;akkor&#160;hozz&aacute;adjuk&#160;a&#160;sorhoz.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;step</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;step</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;step</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;step</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">.</span><span class="csharp_plain">z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;most&#160;kell&#160;visszal&eacute;pegetni,&#160;k&eacute;rd&eacute;s,&#160;hogy&#160;melyik&#160;dimenzi&oacute;b&oacute;l&#160;indulunk?</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;dim</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">!=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">!=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">n-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">].</span><span class="csharp_plain">step&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;dim&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;StreamWriter&#160;outs&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamWriter</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;labi.ki&quot;</span><span class="csharp_operator">+</span><span class="csharp_plain">input</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;dim&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;nem&#160;tal&aacute;ltunk&#160;megold&aacute;st!</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;outs</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_num_literal">0</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;van&#160;megold&aacute;s,&#160;&eacute;s&#160;tudjuk,&#160;melyik&#160;dimenzi&oacute;ban</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;(n-1,&#160;m-1,&#160;dim)-ből&#160;kell&#160;visszal&eacute;pegetni.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;n-1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;m-1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;z&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;dim</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;step&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;table</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">].</span><span class="csharp_plain">step</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;outs</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;step&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Stack</span><span class="csharp_operator">&lt;</span><span class="csharp_type">char</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;way&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Stack</span><span class="csharp_operator">&lt;</span><span class="csharp_type">char</span><span class="csharp_operator">&gt;</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">step</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//&#160;tudjuk,&#160;hogy&#160;csak&#160;step-szer&#160;kell&#160;lefutnia.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;stepBack</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//&#160;balra&#160;l&eacute;p&uuml;nk,&#160;de&#160;visszafele,&#160;azaz&#160;val&oacute;j&aacute;ban&#160;jobbra&#160;l&eacute;pt&uuml;nk.</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Push</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'J'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">continue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;stepBack</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Push</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'B'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">continue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;stepBack</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Push</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'L'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">continue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;stepBack</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">ref</span><span class="csharp_plain">&#160;z</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Push</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'F'</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">continue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">while</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Count&#160;</span><span class="csharp_operator">!=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;outs</span><span class="csharp_separator">.</span><span class="csharp_plain">Write</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;way</span><span class="csharp_separator">.</span><span class="csharp_plain">Pop</span><span class="csharp_separator">()</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;outs</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;outs</span><span class="csharp_separator">.</span><span class="csharp_plain">Close</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//new&#160;Labyrinth(0);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">&lt;=</span><span class="csharp_num_literal">8</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Labyrinth</span><span class="csharp_separator">(</span><span class="csharp_plain">i</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0809/13ora/labirintus/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:24:48
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
