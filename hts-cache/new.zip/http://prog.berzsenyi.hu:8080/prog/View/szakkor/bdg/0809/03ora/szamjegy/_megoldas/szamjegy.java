<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java">szamjegy.java</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_selected">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2868';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2962';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3009';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=3063';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3126';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3213';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3235';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3313';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3353';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3373';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3415';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=3459';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3492';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3527';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3623';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3662';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3715';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3741';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3764';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3782';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=3800';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3813';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3880';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3901';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3933';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=3934';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=3957';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=3951';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=3958';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=3959';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/03ora">3. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2868">1. óra - Ismétléses variáció</option><option  value="2962">2. óra - Permutáció</option><option  selected="selected"  value="3009">3. óra</option><option  value="3063">4. óra</option><option  value="3126">5. óra - Kombináció</option><option  value="3213">6. óra - Partíció</option><option  value="3235">7. óra - Halmaz-partíció</option><option  value="3313">8. óra - Floyd-Warshall algoritmus</option><option  value="3353">9. óra - Dijsktra</option><option  value="3373">10. óra - Szélességi és mélységi bejárás</option><option  value="3415">11. óra</option><option  value="3459">12. óra</option><option  value="3492">13. óra</option><option  value="3527">14. óra</option><option  value="3623">15. óra</option><option  value="3662">16. óra</option><option  value="3715">17. óra</option><option  value="3741">18. óra</option><option  value="3764">19. óra</option><option  value="3782">20. óra</option><option  value="3800">21. óra</option><option  value="3813">22. óra</option><option  value="3880">25. óra</option><option  value="3901">26. óra</option><option  value="3933">27. óra</option><option  value="3934">28. óra</option><option  value="3957">29. óra</option><option  value="3951">30. óra - Kifejezés kiértékelés</option><option  value="3958">31. óra</option><option  value="3959">32. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 30) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=3663';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=3223';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3354';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2869';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3805';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3460';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3128';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3374';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3783';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3814';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3493';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2963';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3801';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3816';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3815';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3765';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3010';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3314';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3236';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3416';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=106';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3064';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3417';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3461';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3766';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy">Számjegyek kitalálása</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="3663">Apokaliptikus sorrend</option><option  value="3223">Bolgár szoliter</option><option  value="3354">Buszok</option><option  value="2869">Fej vagy írás</option><option  value="3805">Fuvarozás</option><option  value="3460">Hálózat</option><option  value="3128">Vektorok</option><option  value="3374">Idegenvezetés</option><option  value="3783">Kincsvadász</option><option  value="3814">Konténerek</option><option  value="3493">Labirintus</option><option  value="2963">Langford permutációk</option><option  value="3801">Négyzetek</option><option  value="3816">PC összeszerelés</option><option  value="3815">Pingvinek menetelése</option><option  value="3765">Póker</option><option  selected="selected"  value="3010">Számjegyek kitalálása</option><option  value="3314">Szerkezetek</option><option  value="3236">Szigetek</option><option  value="3416">Tagok</option><option  value="106">Terv</option><option  value="3064">Választási rendszerek</option><option  value="3417">Város</option><option  value="3461">Vidámpark</option><option  value="3766">Zárójelek</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 25) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0809/03ora">3. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy">Számjegyek kitalálása</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809">2008/2009</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/03ora">3. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy">Számjegyek kitalálása</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java">szamjegy.java</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas/szamjegy.java">szamjegy.java</a>
        
            (<a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="3062" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 9 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.java_annotation {
color: #0050d7;  font-weight: bold;
}
.java_javadoc_comment {
color: rgb(147,147,147); font-style: italic;
}
.java_javadoc_tag {
color: rgb(147,147,147); font-style: italic; font-weight: bold;
}
.java_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_user_type {
color: #0095ff;  font-weight: bold;
}
.java_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.java_type {
color: rgb(128,0,0);
}
.java_operator {
color: rgb(0,0,0);
}
.java_char_literal {
color: rgb(255,0,255);
}
.java_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.java_num_literal {
color: rgb(0,0,255);
}
.java_comment {
color: rgb(147,147,147);  
}
.java_plain {
color: rgb(0,0,0);
}
.java_string_literal {
color: rgb(255,0,0);
}
.java_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="java_comment">/*</span><br /><span class="java_comment">&#160;*&#160;Az&#160;http://prog.berzsenyi.hu:8080/prog/View/szakkor/bdg/0809/03ora/szamjegy&#160;oldalon&#160;tal&aacute;lhat&oacute;&#160;feladatot&#160;oldja&#160;meg&#160;a&#160;program.</span><br /><span class="java_comment">&#160;*&#160;A&#160;szamjegy.be&#160;f&aacute;jlb&oacute;l&#160;beolvasunk&#160;hasonl&oacute;&#160;sorokat:&#160;USA+USSR=PEACE</span><br /><span class="java_comment">&#160;*&#160;A&#160;szamjegy.ki&#160;f&aacute;jlba&#160;&iacute;runk&#160;hasonl&oacute;&#160;sorokat:&#160;932+9338=10270</span><br /><span class="java_comment">&#160;*&#160;</span><br /><span class="java_comment">&#160;*&#160;Algoritmus&#160;r&ouml;viden:</span><br /><span class="java_comment">&#160;*&#160;&#160;1.&#160;&#160;beolvassuk&#160;a&#160;sorokat&#160;a&#160;bemeneti&#160;f&aacute;jlb&oacute;l,&#160;melyekből&#160;Problem&#160;objektumokat&#160;csin&aacute;lunk</span><br /><span class="java_comment">&#160;*&#160;&#160;2.&#160;&#160;values&#160;=&#160;[0,9]&#160;-&gt;&#160;ezt&#160;permut&aacute;ljuk,&#160;majd&#160;megpr&oacute;b&aacute;ljuk&#160;a&#160;probl&eacute;m&aacute;kra&#160;ezeket&#160;r&aacute;illeszteni:</span><br /><span class="java_comment">&#160;*&#160;&#160;&#160;&#160;&#160;&#160;Ha&#160;az&#160;adott&#160;probl&eacute;m&aacute;ban&#160;n&#160;k&uuml;l&ouml;nb&ouml;ző&#160;sz&aacute;mjegy&#160;van,&#160;akkor&#160;a&#160;values&#160;első&#160;n&#160;&eacute;rt&eacute;k&eacute;t&#160;illesztj&uuml;k&#160;r&aacute;&#160;a&#160;sz&aacute;mjegyekre.</span><br /><span class="java_comment">&#160;*&#160;&#160;&#160;&#160;&#160;&#160;Csak&#160;akkor&#160;t&ouml;rt&eacute;nik&#160;illeszt&eacute;s&#160;az&#160;adott&#160;probl&eacute;m&aacute;ra,&#160;ha&#160;a&#160;permut&aacute;ci&oacute;&#160;az&#160;előzőh&ouml;z&#160;k&eacute;pest&#160;az&#160;első&#160;n&#160;&eacute;rt&eacute;ken&#160;v&aacute;ltoztatott&#160;(k&uuml;l&ouml;nben&#160;nincs&#160;&eacute;rtelme,&#160;hiszen&#160;ugyanazokat&#160;a&#160;sz&aacute;mokat&#160;kapn&aacute;nk.</span><br /><span class="java_comment">&#160;*&#160;&#160;3.&#160;&#160;Egy&#160;adott&#160;illeszt&eacute;s&#160;ut&aacute;n&#160;ellenőrizz&uuml;k,&#160;hogy&#160;az&#160;&ouml;sszeg&#160;val&oacute;ban&#160;helyes&#160;(matematikailag),&#160;hiszen&#160;ha&#160;nem,&#160;akkor&#160;a&#160;k&ouml;vi&#160;permut&aacute;ci&oacute;t&#160;keress&uuml;k</span><br /><span class="java_comment">&#160;*&#160;&#160;&#160;&#160;&#160;&#160;Ennek&#160;egyszerű&#160;&eacute;s&#160;gyors&#160;megval&oacute;s&iacute;t&aacute;sa,&#160;hogy&#160;&uacute;gy&#160;adjuk&#160;&ouml;ssze&#160;a&#160;sz&aacute;mokat,&#160;ahogy&#160;mi&#160;is&#160;tenn&eacute;nk&#160;(elősz&ouml;r&#160;az&#160;egyes&#160;helyi&eacute;rt&eacute;ken&#160;&aacute;ll&oacute;&#160;-&gt;&#160;tizes&#160;helyi&eacute;rt&eacute;k&#160;stb.)</span><br /><span class="java_comment">&#160;*&#160;&#160;&#160;&#160;&#160;&#160;Ha&#160;valamelyik&#160;helyi&eacute;rt&eacute;k&#160;nem&#160;stimmel&#160;(nem&#160;egyenlő&#160;a&#160;bal&#160;&eacute;s&#160;jobb&#160;oldalon),&#160;akkor&#160;tov&aacute;bb&#160;l&eacute;p&uuml;nk</span><br /><span class="java_comment">&#160;*&#160;&#160;4.&#160;&#160;A&#160;j&oacute;&#160;megold&aacute;sokat&#160;Solution&#160;objektumk&eacute;nt&#160;egy&#160;t&ouml;mbben&#160;t&aacute;roljuk,&#160;majd&#160;a&#160;v&eacute;g&eacute;n&#160;ezt&#160;iter&aacute;lva,&#160;ki&iacute;juk&#160;a&#160;j&oacute;&#160;megold&aacute;sokat.</span><br /><span class="java_comment">&#160;*&#160;</span><br /><span class="java_comment">&#160;*&#160;K&eacute;sz&iacute;tette:&#160;Kriv&aacute;n&#160;B&aacute;lint</span><br /><span class="java_comment">&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">package</span><span class="java_plain">&#160;hu</span><span class="java_separator">.</span><span class="java_plain">krivan</span><span class="java_separator">.</span><span class="java_plain">szakkor</span><span class="java_separator">.</span><span class="java_plain">szamjegy</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">import</span><span class="java_plain">&#160;java</span><span class="java_separator">.</span><span class="java_plain">util</span><span class="java_separator">.</span><span class="java_operator">*</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_keyword">import</span><span class="java_plain">&#160;java</span><span class="java_separator">.</span><span class="java_plain">io</span><span class="java_separator">.</span><span class="java_operator">*</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">static</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;values</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;*&#160;Egy&#160;megoldand&oacute;&#160;probl&eacute;m&aacute;t&#160;k&eacute;pviselő&#160;objektum.</span><br /><span class="java_javadoc_comment">&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;*&#160;</span><span class="java_javadoc_tag">@author</span><span class="java_javadoc_comment">&#160;balint</span><br /><span class="java_javadoc_comment">&#160;*/</span><span class="java_plain"></span><br /><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Problem</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_comment">/*</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;*&#160;itt&#160;tal&aacute;lhat&oacute;ak,&#160;az&#160;egyes&#160;sz&aacute;mok,&#160;&eacute;s&#160;azok&#160;sz&aacute;mjegyeinek&#160;indexei&#160;(amik&#160;a&#160;values[]-ra&#160;mutatnak)</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;*&#160;teh&aacute;t,&#160;egy&#160;sz&aacute;m&#160;adott&#160;helyi&eacute;rt&eacute;k&eacute;n&#160;szereplő&#160;sz&aacute;mjegy&#160;=&#160;values[&#160;numbers[szam][helyiertek]&#160;]</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Integer</span><span class="java_operator">&gt;&gt;</span><span class="java_plain">&#160;numbers&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Integer</span><span class="java_operator">&gt;&gt;</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;maxIdx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;ez&#160;t&aacute;rolja&#160;az&#160;egyenlős&eacute;gjel&#160;&quot;poz&iacute;ci&oacute;j&aacute;t&quot;&#160;-&gt;&#160;innen&#160;tudjuk,&#160;hogy&#160;ha&#160;n&eacute;zz&uuml;k&#160;a&#160;sz&aacute;mokat,&#160;akkor&#160;melyiktől&#160;kezdve&#160;vannak&#160;a&#160;sz&aacute;mok&#160;az&#160;egyenlős&eacute;g&#160;jobb&#160;oldal&aacute;n</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;eqIndex&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;id&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;getIdxFromChar</span><span class="java_separator">(</span><span class="java_type">char</span><span class="java_plain">&#160;a</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_separator">)</span><span class="java_plain">&#160;a&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">65</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_user_type">Problem</span><span class="java_separator">(</span><span class="java_user_type">String</span><span class="java_plain">&#160;s</span><span class="java_separator">,</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;idx</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;id&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;idx</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;eqSides&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;s</span><span class="java_separator">.</span><span class="java_plain">split</span><span class="java_separator">(</span><span class="java_string_literal">&quot;=&quot;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">eqSides</span><span class="java_separator">.</span><span class="java_plain">length&#160;</span><span class="java_operator">!=</span><span class="java_plain">&#160;</span><span class="java_num_literal">2</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;numbers1&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;eqSides</span><span class="java_separator">[</span><span class="java_num_literal">0</span><span class="java_separator">].</span><span class="java_plain">split</span><span class="java_separator">(</span><span class="java_string_literal">&quot;</span><span class="java_esc_string_literal">\\</span><span class="java_string_literal">+&quot;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;eqIndex&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;numbers1</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ahol&#160;az&#160;egyenlős&eacute;gjel&#160;van.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;numbers2&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;eqSides</span><span class="java_separator">[</span><span class="java_num_literal">1</span><span class="java_separator">].</span><span class="java_plain">split</span><span class="java_separator">(</span><span class="java_string_literal">&quot;</span><span class="java_esc_string_literal">\\</span><span class="java_string_literal">+&quot;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;numbers_&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">String</span><span class="java_separator">[</span><span class="java_plain">numbers1</span><span class="java_separator">.</span><span class="java_plain">length&#160;</span><span class="java_operator">+</span><span class="java_plain">&#160;numbers2</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers1</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;numbers_</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;numbers1</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers2</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;numbers_</span><span class="java_separator">[</span><span class="java_plain">i&#160;</span><span class="java_operator">+</span><span class="java_plain">&#160;numbers1</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;numbers2</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;itt&#160;t&aacute;roljuk&#160;ideiglenesen&#160;azt,&#160;hogy&#160;az&#160;adott&#160;karaktert&#160;hol&#160;tal&aacute;ltuk&#160;meg&#160;elősz&ouml;r&#160;(ez&#160;ahhoz&#160;kell,&#160;hogy&#160;minden&#160;karaktert&#160;egy&#160;0-9-ig&#160;eső&#160;sz&aacute;mmal&#160;jellemezhess&uuml;nk)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;indicies&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[</span><span class="java_num_literal">26</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;</span><span class="java_num_literal">26</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;indicies</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;v&eacute;grehajtunk&#160;egy&#160;karakter-anal&iacute;zist,&#160;hogy&#160;a&#160;karakterekből&#160;sz&aacute;mokat&#160;tudjunk&#160;csin&aacute;lni.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;c&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers_</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Integer</span><span class="java_operator">&gt;</span><span class="java_plain">&#160;number&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Integer</span><span class="java_operator">&gt;</span><span class="java_separator">();</span><span class="java_plain">&#160;</span><span class="java_comment">//ez&#160;egy&#160;sz&aacute;m</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;a&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;a&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers_</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">].</span><span class="java_plain">length</span><span class="java_separator">();</span><span class="java_plain">&#160;a</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;ha&#160;m&eacute;g&#160;nem&#160;volt&#160;ilyen&#160;karakter,&#160;akkor&#160;kapjon&#160;egy&#160;sz&aacute;mot&#160;(0-9)&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">indicies</span><span class="java_separator">[</span><span class="java_plain">getIdxFromChar</span><span class="java_separator">(</span><span class="java_plain">numbers_</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">].</span><span class="java_plain">charAt</span><span class="java_separator">(</span><span class="java_plain">a</span><span class="java_separator">))]</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;indicies</span><span class="java_separator">[</span><span class="java_plain">getIdxFromChar</span><span class="java_separator">(</span><span class="java_plain">numbers_</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">].</span><span class="java_plain">charAt</span><span class="java_separator">(</span><span class="java_plain">a</span><span class="java_separator">))]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;c</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;number</span><span class="java_separator">.</span><span class="java_plain">add</span><span class="java_separator">(</span><span class="java_plain">indicies</span><span class="java_separator">[</span><span class="java_plain">getIdxFromChar</span><span class="java_separator">(</span><span class="java_plain">numbers_</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">].</span><span class="java_plain">charAt</span><span class="java_separator">(</span><span class="java_plain">a</span><span class="java_separator">))]);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;numbers</span><span class="java_separator">.</span><span class="java_plain">add</span><span class="java_separator">(</span><span class="java_plain">number</span><span class="java_separator">);</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;a&#160;sz&aacute;mot&#160;hozz&aacute;adjuk&#160;a&#160;sz&aacute;mokhoz.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">/*</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*&#160;Ebben&#160;a&#160;pillanatban&#160;a&#160;numbers[][]&#160;t&aacute;rolja&#160;a&#160;sz&aacute;mokat&#160;&eacute;s&#160;azok&#160;&quot;sz&aacute;mjegyeit&quot;,&#160;de&#160;az&#160;adott&#160;sz&aacute;mjegy,&#160;csak&#160;egy&#160;index</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*&#160;ami&#160;hely&eacute;re&#160;behelyettes&iacute;tj&uuml;k&#160;a&#160;permut&aacute;ci&oacute;nak&#160;megfelelő&#160;jelenlegi&#160;&eacute;rt&eacute;ket.</span><br /><span class="java_comment">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;maxIdx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;c&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;elt&aacute;roljuk,&#160;hogy&#160;h&aacute;ny&#160;sz&aacute;mot&#160;haszn&aacute;lunk&#160;0-9-ből,&#160;hiszen&#160;a&#160;permut&aacute;ci&oacute;&#160;sor&aacute;n,&#160;ezekkel&#160;nem&#160;foglalkozunk.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;Megvizsg&aacute;ljuk,&#160;hogy&#160;a&#160;probl&eacute;m&aacute;ra&#160;az&#160;adott&#160;permut&aacute;ci&oacute;&#160;ad-e&#160;megold&aacute;st.</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@return</span><span class="java_javadoc_comment">&#160;j&oacute;-e&#160;az&#160;adott&#160;permut&aacute;ci&oacute;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;isGoodPermutation</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;sz&aacute;mjegyeken&#160;v&eacute;gig&#160;megy&uuml;nk.&#160;(h&aacute;tulr&oacute;l)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;X&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;bal&#160;oldal</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;Y&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;jobb&#160;oldal</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;endOfNumbers&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">true</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;</span><span class="java_num_literal">12</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;12&#160;=&#160;max.&#160;sz&aacute;mjegyek,&#160;v&eacute;gig&#160;p&ouml;rgetj&uuml;k&#160;a&#160;sz&aacute;mjegyeket.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers</span><span class="java_separator">.</span><span class="java_plain">size</span><span class="java_separator">();</span><span class="java_plain">&#160;j</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;vegy&uuml;k&#160;sorra&#160;az&#160;&ouml;sszeadand&oacute;kat.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_num_literal">0</span><span class="java_separator">)]</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;valamelyik&#160;sz&aacute;m&#160;0-val&#160;kezdődik,&#160;az&#160;felejtős</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_other_literal">false</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">size</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_operator">&gt;</span><span class="java_plain">&#160;i</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;csak&#160;akkor&#160;adjuk&#160;hozz&aacute;&#160;az&#160;adott&#160;sz&aacute;m&#160;sz&aacute;mjegy&eacute;t,&#160;ha&#160;l&eacute;tezik&#160;;)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;endOfNumbers&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">false</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ezzel&#160;vizsg&aacute;ljuk,&#160;hogy&#160;t&ouml;rt&eacute;nt-e&#160;&ouml;sszead&aacute;s,&#160;ha&#160;ez&#160;true&#160;lenne,&#160;akkor&#160;a&#160;v&eacute;g&eacute;n&#160;kil&eacute;p&uuml;nk,&#160;mert&#160;az&#160;&ouml;sszead&aacute;s&#160;v&eacute;g&eacute;re&#160;&eacute;rt&uuml;nk.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">j&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;eqIndex</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;az&#160;egyenlős&eacute;g&#160;bal&#160;oldal&aacute;n&#160;van</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;X&#160;</span><span class="java_operator">+=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">size</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">)];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;a&#160;jobbon.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Y&#160;</span><span class="java_operator">+=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">).</span><span class="java_plain">size</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">)];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">X&#160;</span><span class="java_operator">%</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_plain">&#160;</span><span class="java_operator">!=</span><span class="java_plain">&#160;Y&#160;</span><span class="java_operator">%</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;az&#160;adott&#160;helyi&eacute;rt&eacute;k&#160;nem&#160;stimmel,&#160;akkor&#160;nem&#160;k&uuml;zd&uuml;nk&#160;tov&aacute;bb&#160;-&gt;&#160;kil&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_other_literal">false</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;marad&eacute;kok&#160;kisz&aacute;mol&aacute;sa</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;X&#160;</span><span class="java_operator">/=</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Y&#160;</span><span class="java_operator">/=</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">endOfNumbers</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;nem&#160;volt&#160;mit&#160;&ouml;sszeadni,&#160;akkor&#160;v&eacute;g&eacute;re&#160;&eacute;rt&uuml;nk&#160;&eacute;s&#160;minden&#160;rendben.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_other_literal">true</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;Ellenőrizz&uuml;k,&#160;hogy&#160;kell-e&#160;a&#160;permut&aacute;ci&oacute;t&#160;ellenőrizni,&#160;hogy&#160;megold&aacute;s-e.&#160;Ny&iacute;lv&aacute;n,&#160;ha&#160;a&#160;permut&aacute;ci&oacute;&#160;a&#160;sz&aacute;munkra</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;&eacute;rdekes&#160;helyen&#160;nem&#160;v&aacute;ltozott,&#160;akkor&#160;f&ouml;l&ouml;slegesen&#160;ne&#160;szenvedj&uuml;nk.</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@param</span><span class="java_javadoc_comment">&#160;j&#160;melyik&#160;az&#160;a&#160;legkisebb&#160;index,&#160;amin&#160;a&#160;permut&aacute;ci&oacute;&#160;v&aacute;ltoztatott</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@return</span><span class="java_javadoc_comment">&#160;kell-e&#160;az&#160;adott&#160;permut&aacute;ci&oacute;t&#160;ellenőriztetni</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;shouldCheck</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;j</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">&lt;=</span><span class="java_plain">&#160;maxIdx</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;*&#160;Egy&#160;megold&aacute;st&#160;k&eacute;pviselő&#160;objektum</span><br /><span class="java_javadoc_comment">&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;*&#160;</span><span class="java_javadoc_tag">@author</span><span class="java_javadoc_comment">&#160;balint</span><br /><span class="java_javadoc_comment">&#160;*/</span><span class="java_plain"></span><br /><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Solution</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Integer</span><span class="java_operator">&gt;&gt;</span><span class="java_plain">&#160;numbers</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;values</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;eqIndex</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;Az&#160;adott&#160;probl&eacute;ma&#160;megold&aacute;s&aacute;t&#160;hozzuk&#160;l&eacute;tre.</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@param</span><span class="java_javadoc_comment">&#160;p&#160;melyik&#160;probl&eacute;m&aacute;ra&#160;van&#160;megold&aacute;sunk.</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_user_type">Solution</span><span class="java_separator">(</span><span class="java_user_type">Problem</span><span class="java_plain">&#160;p</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;numbers&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;p</span><span class="java_separator">.</span><span class="java_plain">numbers</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;eqIndex&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;p</span><span class="java_separator">.</span><span class="java_plain">eqIndex</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">this</span><span class="java_separator">.</span><span class="java_plain">values&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">.</span><span class="java_plain">clone</span><span class="java_separator">();</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;kl&oacute;nozzuk,&#160;mert&#160;ez&#160;folyamatosan&#160;v&aacute;ltozik.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;K&iacute;&iacute;rjuk&#160;a&#160;megfelelő&#160;megold&aacute;st.</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;print</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_user_type">PrintWriter</span><span class="java_plain">&#160;out&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_keyword">throws</span><span class="java_plain">&#160;</span><span class="java_user_type">IOException</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers</span><span class="java_separator">.</span><span class="java_plain">size</span><span class="java_separator">();</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">i&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;eqIndex</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out</span><span class="java_separator">.</span><span class="java_plain">print</span><span class="java_separator">(</span><span class="java_string_literal">&quot;=&quot;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">i&#160;</span><span class="java_operator">!=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out</span><span class="java_separator">.</span><span class="java_plain">print</span><span class="java_separator">(</span><span class="java_string_literal">&quot;+&quot;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">i</span><span class="java_separator">).</span><span class="java_plain">size</span><span class="java_separator">();</span><span class="java_plain">&#160;j</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;itt&#160;t&ouml;rt&eacute;nik&#160;a&#160;&quot;leford&iacute;t&aacute;s&quot;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out</span><span class="java_separator">.</span><span class="java_plain">print</span><span class="java_separator">(</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">numbers</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">i</span><span class="java_separator">).</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">)]);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out</span><span class="java_separator">.</span><span class="java_plain">println</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Program</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Problem</span><span class="java_operator">&gt;</span><span class="java_plain">&#160;problems</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;lastSwappedIdx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_user_type">Program</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//StreamReader&#160;r&#160;=&#160;new&#160;StreamReader(&quot;szamjegy.be&quot;);</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">BufferedReader</span><span class="java_plain">&#160;in&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">null</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">try</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;in&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">BufferedReader</span><span class="java_separator">(</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">FileReader</span><span class="java_separator">(</span><span class="java_string_literal">&quot;szamjegy.be&quot;</span><span class="java_separator">));</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;problems&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">ArrayList</span><span class="java_operator">&lt;</span><span class="java_user_type">Problem</span><span class="java_operator">&gt;</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_plain">&#160;str</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;id&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;beolvassuk&#160;a&#160;sorokat</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">((</span><span class="java_plain">str&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;in</span><span class="java_separator">.</span><span class="java_plain">readLine</span><span class="java_separator">())</span><span class="java_plain">&#160;</span><span class="java_operator">!=</span><span class="java_plain">&#160;</span><span class="java_other_literal">null</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;l&eacute;trehozunk&#160;egy&#160;probl&eacute;m&aacute;t,&#160;az&#160;adott&#160;sorhoz&#160;(&eacute;s&#160;egy&#160;ID-t&#160;kap)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;problems</span><span class="java_separator">.</span><span class="java_plain">add</span><span class="java_separator">(</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Problem</span><span class="java_separator">(</span><span class="java_plain">str</span><span class="java_separator">,</span><span class="java_plain">&#160;id</span><span class="java_operator">++</span><span class="java_separator">));</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">catch</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">IOException</span><span class="java_plain">&#160;ex</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ex</span><span class="java_separator">.</span><span class="java_plain">printStackTrace</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">finally</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">try</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;in</span><span class="java_separator">.</span><span class="java_plain">close</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">catch</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">IOException</span><span class="java_plain">&#160;ex</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ex</span><span class="java_separator">.</span><span class="java_plain">printStackTrace</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">static</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;main</span><span class="java_separator">(</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;args</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Program</span><span class="java_plain">&#160;p&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Program</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;p</span><span class="java_separator">.</span><span class="java_plain">solveProblems</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;solveProblems</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;inicializ&aacute;ljuk&#160;a&#160;permut&aacute;ci&oacute;&#160;1.&#160;elem&eacute;t.&#160;[0,9]</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[</span><span class="java_num_literal">10</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;i</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Solution</span><span class="java_separator">[]</span><span class="java_plain">&#160;solutions&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Solution</span><span class="java_separator">[</span><span class="java_plain">problems</span><span class="java_separator">.</span><span class="java_plain">size</span><span class="java_separator">()];</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Problem</span><span class="java_plain">&#160;p</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">do</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;az&#160;adott&#160;permut&aacute;ci&oacute;t&#160;mindegyik&#160;probl&eacute;m&aacute;ra&#160;lefuttatjuk.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;problems</span><span class="java_separator">.</span><span class="java_plain">size</span><span class="java_separator">();</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;p&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;problems</span><span class="java_separator">.</span><span class="java_plain">get</span><span class="java_separator">(</span><span class="java_plain">i</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">p</span><span class="java_separator">.</span><span class="java_plain">shouldCheck</span><span class="java_separator">(</span><span class="java_plain">lastSwappedIdx</span><span class="java_separator">))</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;van&#160;&eacute;rtelme&#160;ellenőrizni.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">p</span><span class="java_separator">.</span><span class="java_plain">isGoodPermutation</span><span class="java_separator">())</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;megold&aacute;s</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;solutions</span><span class="java_separator">[</span><span class="java_plain">p</span><span class="java_separator">.</span><span class="java_plain">id</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Solution</span><span class="java_separator">(</span><span class="java_plain">p</span><span class="java_separator">);</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;elt&aacute;roljuk&#160;a&#160;megold&aacute;st.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;problems</span><span class="java_separator">.</span><span class="java_plain">remove</span><span class="java_separator">(</span><span class="java_plain">&#160;p&#160;</span><span class="java_separator">);</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;megoldva,&#160;kivessz&uuml;k&#160;a&#160;list&aacute;b&oacute;l.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">problems</span><span class="java_separator">.</span><span class="java_plain">size</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;ha&#160;elfogytak&#160;a&#160;megoldand&oacute;&#160;probl&eacute;m&aacute;k,&#160;akkor&#160;k&ouml;sz&ouml;nj&uuml;nk&#160;el.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">hasNextPermutation</span><span class="java_separator">());</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;k&ouml;vetekező&#160;permut&aacute;ci&oacute;t&#160;n&eacute;zz&uuml;k.</span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;ki&iacute;rjuk&#160;a&#160;megold&aacute;sokat</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">PrintWriter</span><span class="java_plain">&#160;out&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">null</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">try</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">PrintWriter</span><span class="java_separator">(</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">FileWriter</span><span class="java_separator">(</span><span class="java_string_literal">&quot;szamjegy.ki&quot;</span><span class="java_separator">));</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;solutions</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;solutions</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">].</span><span class="java_plain">print</span><span class="java_separator">(</span><span class="java_plain">&#160;out&#160;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">catch</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">IOException</span><span class="java_plain">&#160;ex</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ex</span><span class="java_separator">.</span><span class="java_plain">printStackTrace</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">finally</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;out</span><span class="java_separator">.</span><span class="java_plain">close</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;Permut&aacute;ci&oacute;&#160;gener&aacute;l&oacute;&#160;algoritmus</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@return</span><span class="java_javadoc_comment">&#160;van-e&#160;&uacute;jabb&#160;permut&aacute;ci&oacute;</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;hasNextPermutation</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;j</span><span class="java_separator">,</span><span class="java_plain">&#160;m</span><span class="java_separator">,</span><span class="java_plain">&#160;k</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;n&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">10</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;10&#160;elemű&#160;permut&aacute;ci&oacute;:&#160;[0,9]</span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;j&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;n&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">2</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;h&aacute;tulr&oacute;l&#160;kolb&aacute;szolunk&#160;előre&#160;(az&eacute;rt&#160;-2,&#160;mert&#160;-1&#160;lenne&#160;az&#160;utols&oacute;&#160;elem,&#160;de&#160;nek&uuml;nk&#160;az&#160;utols&oacute;&#160;előtti&#160;kell.)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">j</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">&gt;=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">j&#160;</span><span class="java_operator">+</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">])</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;j</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">j&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;k&uuml;l&ouml;nben&#160;exception.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">j&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_other_literal">false</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;nem&#160;tal&aacute;ltunk&#160;cser&eacute;lni&#160;val&oacute;t.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;n&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;megint&#160;h&aacute;tulr&oacute;l&#160;kolb&aacute;szolunk&#160;előre&#160;&eacute;s&#160;megkeress&uuml;k&#160;az&#160;első&#160;olyan&#160;elemet,&#160;amely&#160;nagyobb&#160;j.-n&eacute;l</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">j</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">&gt;=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">m</span><span class="java_separator">])</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">m&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;lehet&#160;ilyen?</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lastSwappedIdx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;j</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;elmentj&uuml;k,&#160;hogy&#160;melyik&#160;a&#160;legkisebb&#160;indexű&#160;elem,&#160;amin&#160;v&aacute;ltoztattunk.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;swap</span><span class="java_separator">(</span><span class="java_plain">j</span><span class="java_separator">,</span><span class="java_plain">&#160;m</span><span class="java_separator">);</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;kicser&eacute;lj&uuml;k&#160;a&#160;k&eacute;t&#160;fekete&#160;b&aacute;r&aacute;nyt.</span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;k&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;j&#160;</span><span class="java_operator">+</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;n&#160;</span><span class="java_operator">-</span><span class="java_plain">&#160;</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;(j+1;&#160;n)&#160;intervallumban&#160;minden&#160;elemet&#160;felcser&eacute;l&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">k&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;m</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;swap</span><span class="java_separator">(</span><span class="java_plain">k</span><span class="java_operator">++</span><span class="java_separator">,</span><span class="java_plain">&#160;m</span><span class="java_operator">--</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_other_literal">true</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;swap</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;j</span><span class="java_separator">,</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;m</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;tmp&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">j</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">j</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">m</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Common</span><span class="java_separator">.</span><span class="java_plain">values</span><span class="java_separator">[</span><span class="java_plain">m</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;tmp</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0809/03ora/szamjegy/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:21:44
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
