<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs">tb_regiok.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_selected">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2112';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2113';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=2115';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2116';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=2118';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=2119';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=2120';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=2125';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=2124';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=2126';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=2127';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2128';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=2129';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=1565';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=2131';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=2132';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=2133';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=2134';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=2137';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=2138';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=1632';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=1650';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=2141';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=2142';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=2143';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=2144';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=2145';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0607/10ora">10. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2112">1. óra</option><option  value="2113">2. óra</option><option  value="2115">3. óra</option><option  value="2116">4. óra</option><option  value="2118">5. óra</option><option  value="2119">6. óra</option><option  value="2120">7. óra</option><option  value="2125">8. óra</option><option  value="2124">9. óra</option><option  selected="selected"  value="2126">10. óra</option><option  value="2127">11. óra</option><option  value="2128">12. óra</option><option  value="2129">13. óra</option><option  value="1565">14. óra</option><option  value="2131">15. óra</option><option  value="2132">16. óra</option><option  value="2133">17. óra</option><option  value="2134">18. óra</option><option  value="2137">19. óra</option><option  value="2138">20. óra</option><option  value="1632">21. óra</option><option  value="1650">22. óra</option><option  value="2141">23. óra</option><option  value="2142">24. óra</option><option  value="2143">25. óra</option><option  value="2144">26. óra</option><option  value="2145">27. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 27) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=1677';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=1701';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=1535';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=1390';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=1674';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=1582';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=1312';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=1396';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=1584';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=1615';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=1633';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=1522';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=1568';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=1688';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=1573';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=1540';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=1352';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=1592';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=1383';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=1374';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=1456';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=1513';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=1661';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=1508';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=1666';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=1468';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=1421';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=1656';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=1682';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0607/10ora/regio">Régiók</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="1677">Banda</option><option  value="1701">Connect</option><option  value="1535">Csapatok</option><option  value="1390">DNS</option><option  value="1674">DNS2</option><option  value="1582">Doboz</option><option  value="1312">Dominófedés</option><option  value="1396">Egyiptomi törtek</option><option  value="1584">Fal</option><option  value="1615">Hajók</option><option  value="1633">Háromszög</option><option  value="1522">Hatszög</option><option  value="1568">Kábel</option><option  value="1688">Kamionok</option><option  value="1573">Két út</option><option  value="1540">Konténer</option><option  value="1352">Lámpák</option><option  value="1592">Lapok</option><option  value="1383">NYÁK</option><option  value="1374">Osztály</option><option  value="1456">Parcellák</option><option  value="1513">Parcellák 2.</option><option  value="1661">Pontok</option><option  selected="selected"  value="1508">Régiók</option><option  value="1666">Sakk</option><option  value="1468">Színház</option><option  value="1421">Születésnap</option><option  value="1656">Találka</option><option  value="1682">Túlélő verseny</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 29) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0607/10ora">10. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0607/10ora/parc2">Parcellák 2.</a>
                    
                     <br />
                
                    <a href="/prog/View/szakkor/bdg/0607/10ora/regio">Régiók</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607">2006/2007</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/10ora">10. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/10ora/regio">Régiók</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs">tb_regiok.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas/tb_regiok.cs">tb_regiok.cs</a>
        
            (<a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="1551" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 4 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_plain">﻿</span><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">IO</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;Regiok</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Telepules&#160;</span><span class="csharp_separator">:</span><span class="csharp_plain">&#160;IComparable</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">Telepules</span><span class="csharp_operator">&gt;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;aktualSorszam&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;sorszam</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Telepules</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;X&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Y&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sorszam&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">++</span><span class="csharp_plain">aktualSorszam</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;X</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;set</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">value&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;value&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1000</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentOutOfRangeException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;value&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;x&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;value</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Y</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;set</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">value&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;value&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1000</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentOutOfRangeException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;value&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;y&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;value</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Sorszam</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;sorszam</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Tavolsag</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Abs</span><span class="csharp_separator">(</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">X&#160;</span><span class="csharp_operator">-</span><span class="csharp_plain">&#160;telepules</span><span class="csharp_separator">.</span><span class="csharp_plain">X</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Abs</span><span class="csharp_separator">(</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">Y&#160;</span><span class="csharp_operator">-</span><span class="csharp_plain">&#160;telepules</span><span class="csharp_separator">.</span><span class="csharp_plain">Y</span><span class="csharp_separator">));</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Tavolsag</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;Telepules&#160;telepules2</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules1&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules1&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules2&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules2&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;telepules1</span><span class="csharp_separator">.</span><span class="csharp_plain">Tavolsag</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules2</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;CompareTo</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">Sorszam&#160;</span><span class="csharp_operator">-</span><span class="csharp_plain">&#160;telepules</span><span class="csharp_separator">.</span><span class="csharp_plain">Sorszam</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;override&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;ToString</span><span class="csharp_separator">()</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">.</span><span class="csharp_plain">Format</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;Sorsz&aacute;m:&#160;{0}&quot;</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;Sorszam</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Regio</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">const</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;MaxTelepulesSzam&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">100</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Telepules</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;telepulesek&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Telepules</span><span class="csharp_separator">[</span><span class="csharp_plain">MaxTelepulesSzam</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;telepulesekSzama&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;TelepulesekSzama</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;telepulesekSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Egyesit</span><span class="csharp_separator">(</span><span class="csharp_plain">Regio&#160;regio</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">regio&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;regio&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">TelepulesekSzama&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;regio</span><span class="csharp_separator">.</span><span class="csharp_plain">TelepulesekSzama&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;MaxTelepulesSzam</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;InvalidOperationException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;Nem&#160;lehet&#160;egyes&iacute;teni&#160;a&#160;k&eacute;t&#160;r&eacute;gi&oacute;t.&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;regio</span><span class="csharp_separator">.</span><span class="csharp_plain">TelepulesekSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;telepulesek</span><span class="csharp_separator">[</span><span class="csharp_plain">telepulesekSzama</span><span class="csharp_operator">++</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;regio</span><span class="csharp_separator">.</span><span class="csharp_plain">telepulesek</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regio</span><span class="csharp_separator">.</span><span class="csharp_plain">telepulesekSzama&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">bool</span><span class="csharp_plain">&#160;Szomszedos</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;tavolsag</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;telepulesekSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules</span><span class="csharp_separator">.</span><span class="csharp_plain">Tavolsag</span><span class="csharp_separator">(</span><span class="csharp_plain">telepulesek</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">])</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">&lt;=</span><span class="csharp_plain">&#160;tavolsag</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">false</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Hozzaad</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepulesekSzama&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;telepulesek</span><span class="csharp_separator">.</span><span class="csharp_plain">Length</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;InvalidOperationException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;A&#160;r&eacute;gi&oacute;&#160;nem&#160;tartalmazhat&#160;t&ouml;bb&#160;telep&uuml;l&eacute;st.&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;telepulesek</span><span class="csharp_separator">[</span><span class="csharp_plain">telepulesekSzama</span><span class="csharp_operator">++</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;telepules</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Kiir</span><span class="csharp_separator">(</span><span class="csharp_plain">TextWriter&#160;writer</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">writer&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Array</span><span class="csharp_separator">.</span><span class="csharp_plain">Sort</span><span class="csharp_separator">(</span><span class="csharp_plain">telepulesek</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;telepulesekSzama</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;telepulesekSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;writer</span><span class="csharp_separator">.</span><span class="csharp_plain">Write</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;{0}&#160;&quot;</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;telepulesek</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Sorszam</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Megye</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Regio</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;regiok</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;regiokSzama</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;maxTavolsag</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Megye</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;maxRegioSzam</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;maxTavolsag</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">maxRegioSzam&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;maxRegioSzam&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">100</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentOutOfRangeException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;maxRegioSzam&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">maxTavolsag&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;maxTavolsag&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1000</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentOutOfRangeException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;maxTavolsag&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Regio</span><span class="csharp_separator">[</span><span class="csharp_plain">maxRegioSzam</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">maxTavolsag&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;maxTavolsag</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;UjTelepules</span><span class="csharp_separator">(</span><span class="csharp_plain">Telepules&#160;telepules</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">throw</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;ArgumentNullException</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;telepules&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;besoroltRegio&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;regiokSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Szomszedos</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;maxTavolsag</span><span class="csharp_separator">))</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">besoroltRegio&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Hozzaad</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;besoroltRegio&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;i</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">besoroltRegio</span><span class="csharp_separator">].</span><span class="csharp_plain">Egyesit</span><span class="csharp_separator">(</span><span class="csharp_plain">regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Torol</span><span class="csharp_separator">(</span><span class="csharp_plain">i</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">besoroltRegio&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">-</span><span class="csharp_num_literal">1</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Regio&#160;regio&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Regio</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regio</span><span class="csharp_separator">.</span><span class="csharp_plain">Hozzaad</span><span class="csharp_separator">(</span><span class="csharp_plain">telepules</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">regiokSzama</span><span class="csharp_operator">++</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;regio</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">private</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Torol</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;index</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">index&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;index&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;regiokSzama</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">index</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_operator">--</span><span class="csharp_plain">regiokSzama</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Kiir</span><span class="csharp_separator">(</span><span class="csharp_plain">TextWriter&#160;writer</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">writer&#160;</span><span class="csharp_operator">==</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">null</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;writer</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">regiokSzama</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;regiokSzama</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Kiir</span><span class="csharp_separator">(</span><span class="csharp_plain">writer</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Progam</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">private</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;Megye&#160;Beolvas</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;fileNev</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">StreamReader&#160;reader&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamReader</span><span class="csharp_separator">(</span><span class="csharp_plain">fileNev</span><span class="csharp_separator">))</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;elso&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;reader</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;n&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">elso</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;t&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">elso</span><span class="csharp_separator">[</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Megye&#160;regiok&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Megye</span><span class="csharp_separator">(</span><span class="csharp_plain">n</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;t</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;=</span><span class="csharp_plain">&#160;n</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;sor&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;reader</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">.</span><span class="csharp_plain">UjTelepules</span><span class="csharp_separator">(</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Telepules</span><span class="csharp_separator">(</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">));</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;regiok</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Megye&#160;regiok&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Beolvas</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;regio.be8&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;regiok</span><span class="csharp_separator">.</span><span class="csharp_plain">Kiir</span><span class="csharp_separator">(</span><span class="csharp_plain">Console</span><span class="csharp_separator">.</span><span class="csharp_plain">Out</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0607/10ora/regio/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:18:55
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
