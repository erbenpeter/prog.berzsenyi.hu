<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java">ep_cella.java</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_selected">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=5169';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=5273';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=5322';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=5356';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=5366';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=5378';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=5402';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5417';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=5462';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=5489';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=5501';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5521';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=5525';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=5536';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=5541';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=5577';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=5593';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=5604';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=5617';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=5670';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=5672';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=5696';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=5714';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=5728';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=5779';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5821';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5824';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5830';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/1011/07ora">7. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="5169">1. óra</option><option  value="5273">2. óra</option><option  value="5322">3. óra</option><option  value="5356">4. óra</option><option  value="5366">5. óra</option><option  value="5378">6. óra</option><option  selected="selected"  value="5402">7. óra</option><option  value="5417">8. óra</option><option  value="5462">9. óra</option><option  value="5489">10. óra</option><option  value="5501">11. óra</option><option  value="5521">12. óra</option><option  value="5525">13. óra</option><option  value="5536">14. óra</option><option  value="5541">15. óra</option><option  value="5577">16. óra</option><option  value="5593">17. óra</option><option  value="5604">18. óra</option><option  value="5617">19. óra</option><option  value="5670">20. óra</option><option  value="5672">21. óra</option><option  value="5696">22. óra</option><option  value="5714">23. óra</option><option  value="5728">24. óra</option><option  value="5779">25. óra</option><option  value="5821">26. óra</option><option  value="5824">27. óra</option><option  value="5830">28. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 28) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=5490';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=5526';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=5729';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=5334';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=5388';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=5697';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=5679';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5578';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=5505';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=5543';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=5279';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5618';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=5542';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=5605';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=5546';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=5677';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=5678';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=5468';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=5715';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=5463';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=5212';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=5357';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=5545';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=5673';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=5367';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5706';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5676';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5544';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=5734';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=5598';
        }
        if (selObj.selectedIndex == 31) {
            window.location = '/prog/Resolve?node=5831';
        }
        if (selObj.selectedIndex == 32) {
            window.location = '/prog/Resolve?node=5404';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/1011/07ora/whitecell">Fehér cella</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;&gt;&gt;</td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="5490">Anagramma</option><option  value="5526">Baktériumok</option><option  value="5729">Befektetés</option><option  value="5334">Collatz-sorozat</option><option  value="5388">Csokoládés keksz</option><option  value="5697">Csomózás</option><option  value="5679">Csoport beosztás_2011</option><option  value="5578">Dominó forgatás</option><option  value="5505">Elegáns gyémántok</option><option  value="5543">Fa</option><option  value="5279">Becsületes figyelmeztetés</option><option  value="5618">Fák izomorfiája</option><option  value="5542">Falvak</option><option  value="5605">Hurkok</option><option  value="5546">Játék</option><option  value="5677">Kemence_2011</option><option  value="5678">Képzés_2011</option><option  value="5468">Fűrészmalom</option><option  value="5715">Legnagyobb üres téglalap</option><option  value="5463">Shakespeare</option><option  value="5212">Nagy számok összege</option><option  value="5357">Osztás nagy számokkal</option><option  value="5545">Pakolás</option><option  value="5673">Párok_2011</option><option  value="5367">Gömbök</option><option  value="5706">Pecsételő</option><option  value="5676">Sudoku_2011</option><option  value="5544">Takar</option><option  value="5734">Városnézés</option><option  value="5598">VB2010</option><option  value="5831">Repülőtéri futószalagok</option><option  selected="selected"  value="5404">Fehér cella</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 32) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/1011/07ora">7. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell">Fehér cella</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011">2010/2011</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/07ora">7. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell">Fehér cella</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java">ep_cella.java</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas/ep_cella.java">ep_cella.java</a>
        
            (<a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="5410" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: us-ascii</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: us-ascii <br />
        
        Méret: 1 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.java_annotation {
color: #0050d7;  font-weight: bold;
}
.java_javadoc_comment {
color: rgb(147,147,147); font-style: italic;
}
.java_javadoc_tag {
color: rgb(147,147,147); font-style: italic; font-weight: bold;
}
.java_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_user_type {
color: #0095ff;  font-weight: bold;
}
.java_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.java_type {
color: rgb(128,0,0);
}
.java_operator {
color: rgb(0,0,0);
}
.java_char_literal {
color: rgb(255,0,255);
}
.java_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.java_num_literal {
color: rgb(0,0,255);
}
.java_comment {
color: rgb(147,147,147);  
}
.java_plain {
color: rgb(0,0,0);
}
.java_string_literal {
color: rgb(255,0,0);
}
.java_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="java_keyword">package</span><span class="java_plain">&#160;cella</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Point</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;x</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;y</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_user_type">Point</span><span class="java_separator">(</span><span class="java_type">double</span><span class="java_plain">&#160;xx</span><span class="java_separator">,</span><span class="java_plain">&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;yy</span><span class="java_separator">){</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;x&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;xx</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;y&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;yy</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;mp1p2</span><span class="java_separator">(</span><span class="java_user_type">Point</span><span class="java_plain">&#160;p</span><span class="java_separator">){</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;dx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;x</span><span class="java_operator">-</span><span class="java_plain">p</span><span class="java_separator">.</span><span class="java_plain">x</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;dy&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;y</span><span class="java_operator">-</span><span class="java_plain">p</span><span class="java_separator">.</span><span class="java_plain">y</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;dy&#160;</span><span class="java_operator">/</span><span class="java_plain">&#160;dx</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;mp</span><span class="java_separator">(){</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">4</span><span class="java_operator">*</span><span class="java_plain">x</span><span class="java_operator">/</span><span class="java_plain">y</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;mOut</span><span class="java_separator">(</span><span class="java_type">double</span><span class="java_plain">&#160;B</span><span class="java_separator">){</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;m&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">this</span><span class="java_separator">.</span><span class="java_plain">mp</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_num_literal">2</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">-</span><span class="java_plain">B</span><span class="java_operator">+</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">B</span><span class="java_separator">)</span><span class="java_operator">/</span><span class="java_separator">(</span><span class="java_num_literal">1</span><span class="java_operator">+</span><span class="java_num_literal">2</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">B</span><span class="java_operator">-</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_user_type">Point</span><span class="java_plain">&#160;next</span><span class="java_separator">(</span><span class="java_type">double</span><span class="java_plain">&#160;B</span><span class="java_separator">){</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;m&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;mOut</span><span class="java_separator">(</span><span class="java_plain">B</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;a&#160;</span><span class="java_operator">=</span><span class="java_separator">(</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">x</span><span class="java_operator">-</span><span class="java_num_literal">4</span><span class="java_operator">*</span><span class="java_plain">x</span><span class="java_operator">-</span><span class="java_num_literal">2</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">*</span><span class="java_plain">y</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;b&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;m</span><span class="java_operator">*</span><span class="java_plain">m</span><span class="java_operator">+</span><span class="java_num_literal">4</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;nx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;a</span><span class="java_operator">/</span><span class="java_plain">b</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">double</span><span class="java_plain">&#160;ny&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;m</span><span class="java_operator">*</span><span class="java_separator">(</span><span class="java_plain">nx</span><span class="java_operator">-</span><span class="java_plain">x</span><span class="java_separator">)</span><span class="java_operator">+</span><span class="java_plain">y</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Point</span><span class="java_separator">(</span><span class="java_plain">nx</span><span class="java_separator">,</span><span class="java_plain">ny</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_user_type">String</span><span class="java_plain">&#160;tos</span><span class="java_separator">(){</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;</span><span class="java_string_literal">&quot;(&quot;</span><span class="java_operator">+</span><span class="java_plain">x</span><span class="java_operator">+</span><span class="java_string_literal">&quot;;&#160;&quot;</span><span class="java_operator">+</span><span class="java_plain">y</span><span class="java_operator">+</span><span class="java_string_literal">&quot;)&quot;</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Main</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">static</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;main</span><span class="java_separator">(</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;args</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Point</span><span class="java_plain">&#160;A&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Point</span><span class="java_separator">(</span><span class="java_num_literal">0</span><span class="java_separator">,</span><span class="java_num_literal">10.1</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Point</span><span class="java_plain">&#160;T&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Point</span><span class="java_separator">(</span><span class="java_num_literal">1.4</span><span class="java_separator">,</span><span class="java_operator">-</span><span class="java_num_literal">9.6</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">long</span><span class="java_plain">&#160;step&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">do</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;step</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Point</span><span class="java_plain">&#160;B&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;T</span><span class="java_separator">.</span><span class="java_plain">next</span><span class="java_separator">(</span><span class="java_plain">A</span><span class="java_separator">.</span><span class="java_plain">mp1p2</span><span class="java_separator">(</span><span class="java_plain">T</span><span class="java_separator">));</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">System</span><span class="java_separator">.</span><span class="java_plain">out</span><span class="java_separator">.</span><span class="java_plain">println</span><span class="java_separator">(</span><span class="java_plain">step</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">System</span><span class="java_separator">.</span><span class="java_plain">out</span><span class="java_separator">.</span><span class="java_plain">println</span><span class="java_separator">(</span><span class="java_plain">B</span><span class="java_separator">.</span><span class="java_plain">tos</span><span class="java_separator">());</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;A&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;T</span><span class="java_separator">;</span><span class="java_plain">&#160;T&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;B</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">while</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_operator">!</span><span class="java_separator">(</span><span class="java_plain">T</span><span class="java_separator">.</span><span class="java_plain">x&#160;</span><span class="java_operator">&gt;=</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">0.01</span><span class="java_plain">&#160;</span><span class="java_operator">&amp;&amp;</span><span class="java_plain">&#160;T</span><span class="java_separator">.</span><span class="java_plain">x&#160;</span><span class="java_operator">&lt;=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0.01</span><span class="java_plain">&#160;</span><span class="java_operator">&amp;&amp;</span><span class="java_plain">&#160;T</span><span class="java_separator">.</span><span class="java_plain">y</span><span class="java_operator">&gt;</span><span class="java_num_literal">0</span><span class="java_separator">));</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/1011/07ora/whitecell/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2010-10-26 20:11:02
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
