<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs">mt_darab.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_selected">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2454';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2457';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=2459';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2460';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=2461';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=2462';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=2463';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=2447';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=2478';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=2482';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=2492';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2497';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=2526';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=2533';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=2541';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=2547';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=2552';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=2557';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=2576';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=2585';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=2594';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=2595';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=2596';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=2599';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=2600';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=2601';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0708/10ora">10. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2454">1. óra</option><option  value="2457">2. óra</option><option  value="2459">3. óra</option><option  value="2460">4. óra</option><option  value="2461">5. óra</option><option  value="2462">6. óra</option><option  value="2463">7. óra</option><option  value="2447">8. óra</option><option  value="2478">9. óra</option><option  selected="selected"  value="2482">10. óra</option><option  value="2492">11. óra</option><option  value="2497">12. óra</option><option  value="2526">13. óra</option><option  value="2533">14. óra</option><option  value="2541">15. óra</option><option  value="2547">16. óra</option><option  value="2552">17. óra</option><option  value="2557">18. óra</option><option  value="2576">19. óra</option><option  value="2585">20. óra</option><option  value="2594">21. óra</option><option  value="2595">22. óra</option><option  value="2596">23. óra</option><option  value="2599">24. óra</option><option  value="2600">25. óra</option><option  value="2601">26. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 26) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2553';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2479';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=2483';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2577';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=2473';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=2469';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=2578';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=2498';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=2455';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=2587';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=2448';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2493';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=2586';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=2472';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=2562';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=2558';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=2527';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=2534';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=2458';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0708/10ora/darabol">Darabolás</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="2553">Áramszünet</option><option  value="2479">Sütemények</option><option  selected="selected"  value="2483">Darabolás</option><option  value="2577">Dobókockák</option><option  value="2473">A fáraó lépcsője</option><option  value="2469">Felvételi ponthatár</option><option  value="2578">Go</option><option  value="2498">Indiana Jones</option><option  value="2455">Invariáns</option><option  value="2587">Konvex burok térben</option><option  value="2448">Színes kövek</option><option  value="2493">Fagráf átmérője</option><option  value="2586">Scrabble</option><option  value="2472">Legrövidebb hálózat</option><option  value="2562">Spam</option><option  value="2558">Szarumán serege</option><option  value="2527">Gazdaságos tankolás</option><option  value="2534">Tili-toli</option><option  value="2458">Üldözés</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 19) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0708/10ora">10. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0708/10ora/darabol">Darabolás</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0708">2007/2008</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0708/10ora">10. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0708/10ora/darabol">Darabolás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs">mt_darab.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas/mt_darab.cs">mt_darab.cs</a>
        
            (<a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="2490" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 4 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_comment">/*</span><br /><span class="csharp_comment">&#160;*&#160;K&eacute;sz&iacute;tette&#160;a&#160;SharpDevelop.</span><br /><span class="csharp_comment">&#160;*&#160;Felhaszn&aacute;l&oacute;:&#160;02cmezei</span><br /><span class="csharp_comment">&#160;*&#160;D&aacute;tum:&#160;2007.11.26.</span><br /><span class="csharp_comment">&#160;*&#160;Ido:&#160;14:58</span><br /><span class="csharp_comment">&#160;*</span><br /><span class="csharp_comment">&#160;*&#160;A&#160;sablon&#160;megv&aacute;ltoztat&aacute;s&aacute;hoz&#160;haszn&aacute;lja&#160;az&#160;Eszk&ouml;z&ouml;k&#160;|&#160;Be&aacute;ll&iacute;t&aacute;sok&#160;|&#160;K&oacute;dol&aacute;s&#160;|&#160;Szabv&aacute;ny&#160;Fejl&eacute;cek&#160;Szerkeszt&eacute;s&eacute;t.</span><br /><span class="csharp_comment">&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">IO</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">Collections</span><span class="csharp_separator">.</span><span class="csharp_plain">Generic</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;darab</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Program</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">struct</span><span class="csharp_plain">&#160;Problem</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Problem</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_operator">=</span><span class="csharp_plain">x</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_operator">=</span><span class="csharp_plain">y</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">db</span><span class="csharp_operator">=</span><span class="csharp_plain">db</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;List</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">Problem</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;problems</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;List</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">Problem</span><span class="csharp_operator">&gt;</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">[,,]</span><span class="csharp_plain">&#160;cache</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;Problem&#160;akt</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;munka</span><span class="csharp_separator">(</span><span class="csharp_plain">Problem&#160;p</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;akt</span><span class="csharp_operator">=</span><span class="csharp_plain">p</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cache</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">[</span><span class="csharp_plain">p</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;p</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;p</span><span class="csharp_separator">.</span><span class="csharp_plain">db</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">!=</span><span class="csharp_plain">p</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">!=</span><span class="csharp_plain">p</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cache</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_plain">i</span><span class="csharp_operator">*</span><span class="csharp_plain">j</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;opt</span><span class="csharp_separator">(</span><span class="csharp_plain">p</span><span class="csharp_separator">.</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;p</span><span class="csharp_separator">.</span><span class="csharp_plain">y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;p</span><span class="csharp_separator">.</span><span class="csharp_plain">db</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;opt</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//x*y-os&#160;t&eacute;glalap,&#160;db&#160;r&eacute;szre&#160;osztva,&#160;mennyi&#160;a&#160;minimum</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">((</span><span class="csharp_plain">x</span><span class="csharp_operator">==</span><span class="csharp_num_literal">0</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">y</span><span class="csharp_operator">==</span><span class="csharp_num_literal">0</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">||</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">db</span><span class="csharp_operator">==</span><span class="csharp_num_literal">0</span><span class="csharp_separator">))</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">MaxValue</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//ezt&#160;ki&#160;akarjuk&#160;z&aacute;rni</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">cache</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">]</span><span class="csharp_operator">!=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;cache</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">];</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//m&aacute;r&#160;kisz&aacute;moltuk</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_comment">//ha&#160;nem...</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;min</span><span class="csharp_operator">=</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">MaxValue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;ertek</span><span class="csharp_operator">=</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">MaxValue</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;m1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;m2</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;c</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;c</span><span class="csharp_operator">!=</span><span class="csharp_plain">db</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;c</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//c&#160;a&#160;darabsz&aacute;m</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">!=</span><span class="csharp_plain">x</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//egyik&#160;tengely</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m1</span><span class="csharp_operator">=</span><span class="csharp_plain">opt</span><span class="csharp_separator">(</span><span class="csharp_plain">i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m2</span><span class="csharp_operator">=</span><span class="csharp_plain">opt</span><span class="csharp_separator">(</span><span class="csharp_plain">x-i</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;db-c</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ertek</span><span class="csharp_operator">=</span><span class="csharp_plain">Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Max</span><span class="csharp_separator">(</span><span class="csharp_plain">m1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m2</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">ertek</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">min</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;min</span><span class="csharp_operator">=</span><span class="csharp_plain">ertek</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">!=</span><span class="csharp_plain">y</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_comment">//m&aacute;sik&#160;tengely</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m1</span><span class="csharp_operator">=</span><span class="csharp_plain">opt</span><span class="csharp_separator">(</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;c</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;m2</span><span class="csharp_operator">=</span><span class="csharp_plain">opt</span><span class="csharp_separator">(</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y-j</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;db-c</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ertek</span><span class="csharp_operator">=</span><span class="csharp_plain">Math</span><span class="csharp_separator">.</span><span class="csharp_plain">Max</span><span class="csharp_separator">(</span><span class="csharp_plain">m1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;m2</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">ertek</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">min</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;min</span><span class="csharp_operator">=</span><span class="csharp_plain">ertek</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cache</span><span class="csharp_separator">[</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;db</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_plain">min</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;min</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;megoldasok</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;beolvas</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;darabol.in&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;megoldasok</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">[</span><span class="csharp_plain">problems</span><span class="csharp_separator">.</span><span class="csharp_plain">Count</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">!=</span><span class="csharp_plain">problems</span><span class="csharp_separator">.</span><span class="csharp_plain">Count</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;megoldasok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_plain">munka</span><span class="csharp_separator">(</span><span class="csharp_plain">problems</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;kiir</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;darabol.out&quot;</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;megoldasok</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;beolvas</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;inp</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;TextReader&#160;tr</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamReader</span><span class="csharp_separator">(</span><span class="csharp_plain">inp</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;l</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">while</span><span class="csharp_separator">((</span><span class="csharp_plain">l</span><span class="csharp_operator">=</span><span class="csharp_plain">tr</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">(</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_separator">))[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]</span><span class="csharp_operator">!=</span><span class="csharp_string_literal">&quot;0&quot;</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Problem&#160;p</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Problem</span><span class="csharp_separator">(</span><span class="csharp_plain">ti</span><span class="csharp_separator">(</span><span class="csharp_plain">l</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]),</span><span class="csharp_plain">&#160;ti</span><span class="csharp_separator">(</span><span class="csharp_plain">l</span><span class="csharp_separator">[</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]),</span><span class="csharp_plain">&#160;ti</span><span class="csharp_separator">(</span><span class="csharp_plain">l</span><span class="csharp_separator">[</span><span class="csharp_num_literal">2</span><span class="csharp_separator">]));</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;problems</span><span class="csharp_separator">.</span><span class="csharp_plain">Add</span><span class="csharp_separator">(</span><span class="csharp_plain">p</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;tr</span><span class="csharp_separator">.</span><span class="csharp_plain">Close</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;ti</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;s</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;Convert</span><span class="csharp_separator">.</span><span class="csharp_plain">ToInt32</span><span class="csharp_separator">(</span><span class="csharp_plain">s</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;kiir</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;oup</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;mok</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;TextWriter&#160;tw</span><span class="csharp_operator">=</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamWriter</span><span class="csharp_separator">(</span><span class="csharp_plain">oup</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">!=</span><span class="csharp_plain">mok</span><span class="csharp_separator">.</span><span class="csharp_plain">Length</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;tw</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">mok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;tw</span><span class="csharp_separator">.</span><span class="csharp_plain">Close</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0708/10ora/darabol/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:19:46
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
