<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg_progbev/0809/13ora/Program.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg_progbev/0809/13ora">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg_progbev/0809/13ora/Program.cs">Program.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
&lt;&lt;&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b>Órák</b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;&gt;&gt;</td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 0) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
&lt;&lt;&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b>Feladatok</b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;&gt;&gt;</td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 0) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg_progbev/0809/13ora/Program.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg_progbev/0809/13ora/Program.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg_progbev/0809/13ora">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg_progbev">ProgBev Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg_progbev/0809">2008: C#</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg_progbev/0809/13ora">13.óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg_progbev/0809/13ora/Program.cs">Program.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg_progbev/0809/13ora/Program.cs">Program.cs</a>
        
            (<a href="/prog/View/szakkor/bdg_progbev/0809/13ora">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="3733" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 8 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_comment">/*</span><br /><span class="csharp_comment">&#160;*&#160;K&eacute;sz&iacute;tett&eacute;k&#160;Feh&eacute;r&#160;G&aacute;bor&#160;tan&iacute;tv&aacute;nyai.</span><br /><span class="csharp_comment">&#160;*&#160;Felhaszn&aacute;l&oacute;:&#160;Feh&eacute;r&#160;G&aacute;bor.</span><br /><span class="csharp_comment">&#160;*&#160;D&aacute;tum:&#160;2009.01.28.</span><br /><span class="csharp_comment">&#160;*&#160;Ido:&#160;15:45</span><br /><span class="csharp_comment">&#160;*&#160;</span><br /><span class="csharp_comment">&#160;*&#160;K&ouml;sz&ouml;nj&uuml;k&#160;a&#160;szakk&ouml;r&#160;rendszeres&#160;megtart&aacute;s&aacute;t,</span><br /><span class="csharp_comment">&#160;*&#160;&eacute;s&#160;j&oacute;&#160;utat&#160;k&iacute;v&aacute;nunk&#160;Hollandi&aacute;ba!</span><br /><span class="csharp_comment">&#160;*/</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;aj&aacute;nd&eacute;k</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Program</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Hol</span><span class="csharp_separator">,</span><span class="csharp_plain">landia</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Hol&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;landia&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">SetCursorPosition</span><span class="csharp_separator">(</span><span class="csharp_plain">Hol</span><span class="csharp_separator">,</span><span class="csharp_plain">landia</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,::rSX25isr;;:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,:rs2B@@@#@@@@@@@@@@#A9S;:&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.;2A#@@@@@@@@@#M#@@@@#@@@@@@@#&amp;5r:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,r3M@@@@@@#MM#@@@@##@####@@@@@@@@@@@Ai:&#160;..&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;;B@@@@@HAB####@@@@#MBBM####@@@@@@@##@@@#A9HHs.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.5@@@@###A9B##M########MM##@@@@@@@@@#M#@@@@@@@#s&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.;&amp;@@#AH##BAB@@####MMM#@@####@@#####@@###@@@#@##@#X;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,sh#@@BGA##BAB@@@@@@#######@@######@@@#@@##@#MM@##M#@#s.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.r3A#@#MHAMM###@@@@@####@@@######@@@@@@##@@@@#MHB###@AA@@5&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.s&amp;BB#M&amp;HBM#HM@@@@###@@##@@@@####@@@@@####@@@@@@####@@H9M@@S,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;:5AAG#@#BHB#@#M#AHM##@@@#####@@@@#######@@@@##@@@@###@@MHAA@@3&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;:hBHGhM#HB#MHAB###@@@###########@##########M########BH#@MHHHH#H;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;;XHHAGhB#M###BBM#@@##MMMBBBBBBBM##########@#####MBM##MA&amp;BBM#HhH#G:&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;,X@#HAGAM#@@####MA9252XXXX2222222XG&amp;AAA&amp;AHM############MAHAM#H9&amp;#@X.&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;;A@H&amp;GGH#@@#AGh32Ssrrrsrrrr;;;;rrrrrrrr;rriS2X3hAHM##@@@@M&amp;AMMA&amp;B@H;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;sM#GAAABM##AXSsr;rrrr;;;;;;;;;;;;;:::::::::::::;rsS529AM#MHAM##&amp;9AHS.&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;S#M&amp;BBHM##B2r;;;;rrrrrrrrr;;;;;;;;;;;;;rr;;:::::::::;;rSGM##M##A3GB&amp;;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;.3@BhA#MABMhr::;rrrrrrrrrrrrr;;;;;;;;rrrrrrr;rrrr;;;;;;;;sGM##MM#HXGHi&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;,G#A&amp;ABBHHA2r;;rrrssrrrrrrrrr;;;;r;;;;rrrrrrrrrrrrrrrrrr;;i9M#HH##hhH2.&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;.;H#AHHHBMA2r;;rrrrrrrrrrrrrr;;;rrrr;;;;;;rrrrrrrrrrrrsrsr;;SH#HAM#A3Ah,&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;,5MBAMBHM#&amp;i;;;rrrrrrrrrrrrrrr;;;;;;;;;;;;;rrrrrrrrrrsssssr;s&amp;#MAM#HX&amp;h:&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;:hMHABBBMM9s;;rrrrrrrrrrrrrrrr;;;;;;;;;;;;;rrrrrrrssssssssrrr2M@#M#MhAG:&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;;AHAAAHMMA2r;;rrrrrrrrrrr;;r;;;;;;;;;;;;;;rrrrrrrrsssssssrsr;sA@@BHM&amp;HG:&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;rM&amp;AB&amp;GHMA2r;;;rrsrrrrrrrr;;;;;;;;;;;;;;r;;rrrrrrrrrrsssssssrr9#@BAHBM9:&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;s#HBM&amp;GH#M3s;;;rrrrrrrrr;;;;;;;;;;;;;;;;;;;;;rrrrrrrrsssssssrr5H@#HB##h;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;.2#BMMG9ABAXr;;;rr;;;;rrr;;;;;;;;;;;;;;;;;;;;;;;rr;;;rrrrrsis;;iA##HHBBAs&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;;HMAM#AhG&amp;3i;;;;;rrrr;;rrr;;;;;;;::::::::;;;;;;;r;rrrrrrrrrrr;;iA##MM&amp;&amp;A5.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;5@BAMMHAAG5;,:;;r53Gh2Ssrr;;;;;;;;;;;;;;;;;rrrrrri53&amp;AA&amp;h3s;r;;sG####A&amp;H5.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;.XH2A#HHHA3s:,:sA@@@@@@@@@@H&amp;92sr;;rrrrrrrrsS3A#@@@@@@@@@@@#&amp;Xr:;XM###AAhr&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;.rirA@#BHB3r:;2B@@@#MM#@@@@@@@BG25iiissS555X&amp;#@@@@@@@#MBHHM@@B2;:iH@##HA5,&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;.:r2ABM##2::i9h2srrrsisrr5AAh&amp;BMAXiii52X9AAS,&#160;&#160;;2hh252SsrsS2XhS;sA@#A3Xi:&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;,::;2B#As:;r;:;rrShMHXr;s9G39&amp;AXsrrrrri293s,..r&amp;####MHGX32sri22XG92S;rir.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;:r,,s3&amp;h2s;::;ih####@@@#&amp;9&amp;HA32Xh95si9B&amp;2S3HMH2iA@@@@#BM@MXssi5SSirrrrir.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;;i;:;risii;:;i2&amp;BA25A@@B3X9Gh9h&amp;A9irrs2GHAGGAA2s2H##AhhAAA3ir;rrrrr;;rsi,&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;.;rrr;;:,,;;;rrssrrrs5XX2X3X5XGH&amp;2r;;;ri9AhX2X22X5iSirriirrrr;;r;:;sr;:rS;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;:;;r2S:..,;;;rr;;;;rrsssSX22225Sisr;;;;r5X2523X25iiis;;rr;:;;;si;,:i2S;;r,&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;:rrrr;:,,:;r;;rrrrrrrrrrrssrrriir;;;;;;;s55issiSSiiisrr;;;;;;rii;:,;;;;rr,&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;,rrr;::,,:;rr;;;;rrrrrrr;;;;;;rsr;::;;;:;s55sr;;;;rrrr;;;;rsrrsr;:::;;rrr.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;,rrs;::,,,:;;;;rrrrrrrr;;;rr;rrrr;;;;;;;riSirriirrrrrrrsiS5Ssrr;;::;;sisr,&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;,;rrr;;,.,:;;;;rssrrrrsssrrrrrrrr;;;;;;;rsisrriSS22XXX25iisrrrrr;:;rrsrr;.&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;.::;;r;:,.,:;;;rrrsiiSisrr;rrrrr;rr;;;;;;rS2Sr::;;;rrrrrrrr;;rrr;:;rr;::,&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;.,,:;;;:,.,::;;;;;;;rr;;;;;;rrr;;;;;;;rr;;riSs;:;;:::;;rrssrrrr;;;;;;;:::&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;.,;;;r;:..,::;;r;;;;;;r;rrr;;;;;;;;;;rrrr;;ssr;;;;;;rrrrrrsrrr;::;rrr;,.&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;..,,,...,::::;;;rrrrrr;rrrrS2SisiiiS29h25Sis;;;;;;;rrrrrsrrr:...,,,.&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;..,,::;;;rrrrrr;;;rSXGh3222223GGX5is;;rrrrrrrrrrrrrrr:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,,,:::;;rrrrrrr;rrriSSSS552SiSisrrrr;rrrrrrrrrrsr;;r;.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,:::::;;rrrrrrrrrrrrssrrrrisrsisssssrrrrrrrrrrrssrrr:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.:::::;;;rrrrrrrrrrr;;rr;rr;;rrrrrrrrrrrrrrrsssrrrr;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.::,::::;;;;rrrrr;::;;rrssirrrr;;;;;;rrrrrrrsssrrrr;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,:::;:;;;;;;rrrrri29&amp;AAA&amp;9GA&amp;hX2Ssrrrrrrrrssssrrsr:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.:;;:::::;;rrr59AHHAAHHBBHBBBHHHHAA2srrrrrssiisrr;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,:;:::::;rrssi29XSsrsiiiSSissi52XX5sssssssisissr:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,:;;;;:;rrrr:;;rrrrsisrrrrrssiisrriiiiSSiissis;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;..:;rr;;;rrrrrrrrrrsS2XX3332SSS5225SSSS555SSiir;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,,,,;;r;;rsssssiS522552252XX22522222255555222ir;:.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,;;::;rrrrrriiissiissrrsssiiSSSS555SS5SS5225SSir;.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,;r;;;rr;;;rrrrrrrrrrrsiiiiissssiiiiiiiS2XX2Siiir.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,;rrrrrrrr;;;;;rrrrrrriS25SiisssssiiiS523932Siiir.&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,;rrrsiSiirr;rrrrrrrrrsS22SSissssiii53h93X5iiiSS;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,;;rrsiS55Sirr;;;rssssiiSiiisssiiSS23GG32Siiiii5sr;,&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.;rrrrrriS222isrrsi5SiiissiiiiSS523&amp;GhXSiiiiiiisi@@@@9;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;,si;rsrrrrrsiiSXX2555SSiiiSSiSS52XhGh9X5issiiii52is#@@@@@Mr.&#160;&#160;&#160;&#160;&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;.,:,:S#A;rsrrrrrrrrsi552XX3hhGh339h&amp;AAA&amp;&amp;3SSiiiiSSSii5Ssh@@@@#@@@Ai;,&#160;&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;&#160;&#160;&#160;.:;rXM@#A3##S;rsssrrrrrrrrrssiS5X39hAAh93X25irsSSSSSSSSSSS25riH@@MB#@@@@@#H&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;;s2A#@@@@@#Hh#&amp;;;siissssrsrsiissrrrrrrrrrrrrsiS52225SiiiS555522srh@@MBM####@@@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;@@@#MH#@#HHBH#&amp;ssiiiisisssssssiiSiisr;;rrsiS22222222SiiiiS55222SiA@@MMM#####@#&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;#MHHHBM##HHMBBA5rsSiiiiiiiiisrsiSSSSiisiS2X3X222225SiiiiS52222229#@@M########M&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;MHHHB#BM@#BBM##HSsiSiiiiiiisiiiiiiiS52XX33XX25SS5SiiiiSS55229XS2M@@#M#########&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;MBHHM###@@#B#@@#ASrsiiiissssssiiiiiS552XX222225SSSiiiiSS552XhXSG@@@M#@########&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;#MBM#####@####@@@H2isi5SsrsissiiSSiSSSSSSSSS5SSSSiiiiiiSS2X322H@@@##@@##@@####&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;##MM#@#########@@@@GirriSSiisiiiSSSSSiiiiiiiiiSiiiiiS5555223XA@@@##@@@#@@#@#@#&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;##MM##@@###@@@#@@@@@#hSsiSSiiiiiS555SSiiiiiiiiiiiiSSS2X222X3H@@@##@@##@@@#@@@@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;###########@@@@@@@@@@@#&amp;X2iiiSiiS5255555SSSSSSSSSS55522XXhAM@@@@#@@@##@@##@##@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;########@@####@@@@@@@@@@@#&amp;XSiiiiiSSSSS555SSSSSSS52222X9AM@@@@@@@@@@#@@@######&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;######@@#@######@@@@@@@@@@@@#BAhX25SSiiSSiiiiiiSS5X9&amp;B#@@@@@@@@@@####@@@@@@@@@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;#MM####@@######@@@@@@@@@@@@@@@@@@@@##MH&amp;A&amp;AAAAHBM#@@@@@@@@@@@@@@@####@@@@@@@@@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;#####@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain">&#160;&#160;</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadKey</span><span class="csharp_separator">(</span><span class="csharp_keyword">true</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg_progbev/0809/13ora">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Feh&eacute;r G&aacute;bor;
        utolsó módosítás:
        2009-11-07 23:27:06
        (Feh&eacute;r G&aacute;bor)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
