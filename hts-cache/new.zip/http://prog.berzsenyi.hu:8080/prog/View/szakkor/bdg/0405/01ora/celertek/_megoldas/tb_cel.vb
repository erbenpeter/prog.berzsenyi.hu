<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb">tb_cel.vb</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_selected">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=4';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2012';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=2014';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2016';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=2017';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=24';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=25';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=2020';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=2021';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=2022';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=2023';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2024';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=2025';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=2026';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
&lt;&lt;&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0405/01ora">1. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  selected="selected"  value="4">1. óra</option><option  value="2012">2. óra</option><option  value="2014">3. óra</option><option  value="2016">4. óra</option><option  value="2017">5. óra</option><option  value="24">6. óra</option><option  value="25">7. óra</option><option  value="2020">8. óra</option><option  value="2021">9. óra</option><option  value="2022">10. óra</option><option  value="2023">11. óra</option><option  value="2024">12. óra</option><option  value="2025">13. óra</option><option  value="2026">14. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 14) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=8';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=46';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=45';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=10';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=40';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=41';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=27';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=42';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=28';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=6';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=16';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=7';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=29';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=44';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=32';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=32';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=33';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
&lt;&lt;&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0405/01ora/celertek">Célérték keresés</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  selected="selected"  value="8">Célérték keresés</option><option  value="46">Dominó</option><option  value="45">Építkezés</option><option  value="10">Fazekas</option><option  value="40">Folyók</option><option  value="41">Karaván</option><option  value="27">Kemence</option><option  value="42">Kép</option><option  value="28">Malac</option><option  value="6">Partíció probléma</option><option  value="16">Számolós</option><option  value="7">Szorzattá bontás</option><option  value="29">Teher-fuvar</option><option  value="44">Ütemezés</option><option  value="32">Útvesztő-generálás</option><option  value="32">Útvesztő-generálás</option><option  value="33">Zombik</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 17) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0405/01ora">1. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0405/01ora/celertek">Célérték keresés</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">M.</a>)
                     <br />
                
                    <a href="/prog/View/szakkor/bdg/0405/01ora/particio">Partíció probléma</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0405/01ora/particio/_megoldas">M.</a>)
                     <br />
                
                    <a href="/prog/View/szakkor/bdg/0405/01ora/szorzbont">Szorzattá bontás</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0405/01ora/szorzbont/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0405">2004/2005</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0405/01ora">1. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0405/01ora/celertek">Célérték keresés</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb">tb_cel.vb</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas/tb_cel.vb">tb_cel.vb</a>
        
            (<a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="1014" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: us-ascii</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: us-ascii <br />
        
        Méret: 1 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.vb_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.vb_user_type {
color: #0095ff;  font-weight: bold;
}
.vb_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.vb_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.vb_type {
color: rgb(128,0,0);
}
.vb_operator {
color: rgb(0,0,0);
}
.vb_char_literal {
color: rgb(255,0,255);
}
.vb_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.vb_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.vb_num_literal {
color: rgb(0,0,255);
}
.vb_comment {
color: rgb(147,147,147);  
}
.vb_plain {
color: rgb(0,0,0);
}
.vb_string_literal {
color: rgb(255,0,0);
}
.vb_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="vb_keyword">Module</span><span class="vb_plain">&#160;Celertek</span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Const</span><span class="vb_plain">&#160;ben&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Byte</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">10</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Const</span><span class="vb_plain">&#160;bec&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">101</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">()</span><span class="vb_plain">&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_separator">{</span><span class="vb_num_literal">1</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">2</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">3</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">4</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">5</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">6</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">7</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">8</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">9</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">10</span><span class="vb_separator">}</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;operators</span><span class="vb_separator">()</span><span class="vb_plain">&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Char</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_separator">{</span><span class="vb_char_literal">&quot;+&quot;c</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_char_literal">&quot;-&quot;c</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_char_literal">&quot;*&quot;c</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_char_literal">&quot;/&quot;c</span><span class="vb_separator">}</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;isNotMin&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Boolean</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_keyword">True</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;minDiff&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;minOperators</span><span class="vb_separator">(</span><span class="vb_plain">ben</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Byte</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Private</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Sub</span><span class="vb_plain">&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_separator">,</span><span class="vb_plain">&#160;number&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_separator">,</span><span class="vb_plain">&#160;arrOperator</span><span class="vb_separator">()</span><span class="vb_plain">&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Byte</span><span class="vb_separator">,</span><span class="vb_plain">&#160;op&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Byte</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;level&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;ben&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;isNotMin&#160;</span><span class="vb_keyword">OrElse</span><span class="vb_plain">&#160;Math</span><span class="vb_separator">.</span><span class="vb_plain">Abs</span><span class="vb_separator">(</span><span class="vb_plain">minDiff</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_operator">&gt;</span><span class="vb_plain">&#160;Math</span><span class="vb_separator">.</span><span class="vb_plain">Abs</span><span class="vb_separator">(</span><span class="vb_plain">number&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;bec</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;isNotMin&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_keyword">False</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;minDiff&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;number&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;bec</span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;arrOperator</span><span class="vb_separator">(</span><span class="vb_plain">level</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;op</span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;arrOperator</span><span class="vb_separator">.</span><span class="vb_plain">CopyTo</span><span class="vb_separator">(</span><span class="vb_plain">minOperators</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">If</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">Else</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;arrOperator</span><span class="vb_separator">(</span><span class="vb_plain">level</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;op</span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">,</span><span class="vb_plain">&#160;number&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">),</span><span class="vb_plain">&#160;arrOperator</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">,</span><span class="vb_plain">&#160;number&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">),</span><span class="vb_plain">&#160;arrOperator</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;Math</span><span class="vb_separator">.</span><span class="vb_plain">Abs</span><span class="vb_separator">(</span><span class="vb_type">CLng</span><span class="vb_separator">(</span><span class="vb_plain">number</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_operator">*</span><span class="vb_plain">&#160;</span><span class="vb_type">CLng</span><span class="vb_separator">(</span><span class="vb_plain">bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">)))</span><span class="vb_plain">&#160;</span><span class="vb_operator">&lt;=</span><span class="vb_plain">&#160;</span><span class="vb_type">Integer</span><span class="vb_separator">.</span><span class="vb_plain">MaxValue&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain">&#160;_</span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">,</span><span class="vb_plain">&#160;number&#160;</span><span class="vb_operator">*</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">),</span><span class="vb_plain">&#160;arrOperator</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">2</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_operator">&lt;&gt;</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain">&#160;_</span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">,</span><span class="vb_plain">&#160;number&#160;\&#160;bet</span><span class="vb_separator">(</span><span class="vb_plain">level&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_separator">),</span><span class="vb_plain">&#160;arrOperator</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">3</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">If</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Sub</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">Public</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Sub</span><span class="vb_plain">&#160;Main</span><span class="vb_separator">()</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">Dim</span><span class="vb_plain">&#160;i</span><span class="vb_separator">,</span><span class="vb_plain">&#160;temp</span><span class="vb_separator">(</span><span class="vb_plain">ben</span><span class="vb_separator">)</span><span class="vb_plain">&#160;</span><span class="vb_keyword">As</span><span class="vb_plain">&#160;</span><span class="vb_type">Byte</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;Calculate</span><span class="vb_separator">(</span><span class="vb_num_literal">0</span><span class="vb_separator">,</span><span class="vb_plain">&#160;bet</span><span class="vb_separator">(</span><span class="vb_num_literal">0</span><span class="vb_separator">),</span><span class="vb_plain">&#160;temp</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">Clear</span><span class="vb_separator">()</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">For</span><span class="vb_plain">&#160;i&#160;</span><span class="vb_operator">=</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_plain">&#160;</span><span class="vb_keyword">To</span><span class="vb_plain">&#160;ben&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;i&#160;</span><span class="vb_operator">&gt;</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">0</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">If</span><span class="vb_plain">&#160;i&#160;</span><span class="vb_operator">&gt;</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">1</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Then</span><span class="vb_plain">&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">Write</span><span class="vb_separator">(</span><span class="vb_string_literal">&quot;)&quot;</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">Write</span><span class="vb_separator">(</span><span class="vb_string_literal">&quot;&#160;&quot;</span><span class="vb_plain">&#160;</span><span class="vb_operator">&amp;</span><span class="vb_plain">&#160;operators</span><span class="vb_separator">(</span><span class="vb_plain">minOperators</span><span class="vb_separator">(</span><span class="vb_plain">i</span><span class="vb_separator">))</span><span class="vb_plain">&#160;</span><span class="vb_operator">&amp;</span><span class="vb_plain">&#160;</span><span class="vb_string_literal">&quot;&#160;&quot;</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">Else</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">Write</span><span class="vb_separator">(</span><span class="vb_plain">StrDup</span><span class="vb_separator">(</span><span class="vb_plain">ben&#160;</span><span class="vb_operator">-</span><span class="vb_plain">&#160;</span><span class="vb_num_literal">2</span><span class="vb_separator">,</span><span class="vb_plain">&#160;</span><span class="vb_string_literal">&quot;(&quot;</span><span class="vb_separator">))</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">If</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">Write</span><span class="vb_separator">(</span><span class="vb_plain">bet</span><span class="vb_separator">(</span><span class="vb_plain">i</span><span class="vb_separator">))</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;</span><span class="vb_keyword">Next</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">WriteLine</span><span class="vb_separator">(</span><span class="vb_string_literal">&quot;&#160;=&#160;&quot;</span><span class="vb_plain">&#160;</span><span class="vb_operator">&amp;</span><span class="vb_plain">&#160;bec&#160;</span><span class="vb_operator">+</span><span class="vb_plain">&#160;minDiff</span><span class="vb_separator">)</span><span class="vb_plain"></span><br /><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;&#160;&#160;Console</span><span class="vb_separator">.</span><span class="vb_plain">ReadLine</span><span class="vb_separator">()</span><span class="vb_plain"></span><br /><span class="vb_plain">&#160;&#160;</span><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Sub</span><span class="vb_plain"></span><br /><span class="vb_keyword">End</span><span class="vb_plain">&#160;</span><span class="vb_keyword">Module</span><span class="vb_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0405/01ora/celertek/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Feh&eacute;r G&aacute;bor;
        utolsó módosítás:
        2009-11-07 23:18:00
        (Feh&eacute;r G&aacute;bor)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
