<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java">Langford1.java</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_selected">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2868';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2962';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3009';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=3063';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3126';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3213';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3235';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3313';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3353';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3373';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3415';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=3459';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3492';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3527';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3623';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3662';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3715';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3741';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3764';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3782';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=3800';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3813';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3880';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3901';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3933';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=3934';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=3957';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=3951';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=3958';
        }
        if (selObj.selectedIndex == 30) {
            window.location = '/prog/Resolve?node=3959';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/02ora">2. óra - Permutáció</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2868">1. óra - Ismétléses variáció</option><option  selected="selected"  value="2962">2. óra - Permutáció</option><option  value="3009">3. óra</option><option  value="3063">4. óra</option><option  value="3126">5. óra - Kombináció</option><option  value="3213">6. óra - Partíció</option><option  value="3235">7. óra - Halmaz-partíció</option><option  value="3313">8. óra - Floyd-Warshall algoritmus</option><option  value="3353">9. óra - Dijsktra</option><option  value="3373">10. óra - Szélességi és mélységi bejárás</option><option  value="3415">11. óra</option><option  value="3459">12. óra</option><option  value="3492">13. óra</option><option  value="3527">14. óra</option><option  value="3623">15. óra</option><option  value="3662">16. óra</option><option  value="3715">17. óra</option><option  value="3741">18. óra</option><option  value="3764">19. óra</option><option  value="3782">20. óra</option><option  value="3800">21. óra</option><option  value="3813">22. óra</option><option  value="3880">25. óra</option><option  value="3901">26. óra</option><option  value="3933">27. óra</option><option  value="3934">28. óra</option><option  value="3957">29. óra</option><option  value="3951">30. óra - Kifejezés kiértékelés</option><option  value="3958">31. óra</option><option  value="3959">32. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 30) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=3663';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=3223';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=3354';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2869';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=3805';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=3460';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=3128';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=3374';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=3783';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=3814';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=3493';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2963';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=3801';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=3816';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=3815';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=3765';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=3010';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=3314';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=3236';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=3416';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=106';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=3064';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=3417';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=3461';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=3766';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0809/02ora/langford">Langford permutációk</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="3663">Apokaliptikus sorrend</option><option  value="3223">Bolgár szoliter</option><option  value="3354">Buszok</option><option  value="2869">Fej vagy írás</option><option  value="3805">Fuvarozás</option><option  value="3460">Hálózat</option><option  value="3128">Vektorok</option><option  value="3374">Idegenvezetés</option><option  value="3783">Kincsvadász</option><option  value="3814">Konténerek</option><option  value="3493">Labirintus</option><option  selected="selected"  value="2963">Langford permutációk</option><option  value="3801">Négyzetek</option><option  value="3816">PC összeszerelés</option><option  value="3815">Pingvinek menetelése</option><option  value="3765">Póker</option><option  value="3010">Számjegyek kitalálása</option><option  value="3314">Szerkezetek</option><option  value="3236">Szigetek</option><option  value="3416">Tagok</option><option  value="106">Terv</option><option  value="3064">Választási rendszerek</option><option  value="3417">Város</option><option  value="3461">Vidámpark</option><option  value="3766">Zárójelek</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 25) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0809/02ora">2. óra - Permutáció</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0809/02ora/langford">Langford permutációk</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809">2008/2009</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/02ora">2. óra - Permutáció</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/02ora/langford">Langford permutációk</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java">Langford1.java</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas/Langford1.java">Langford1.java</a>
        
            (<a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="2980" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 2 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.java_annotation {
color: #0050d7;  font-weight: bold;
}
.java_javadoc_comment {
color: rgb(147,147,147); font-style: italic;
}
.java_javadoc_tag {
color: rgb(147,147,147); font-style: italic; font-weight: bold;
}
.java_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_user_type {
color: #0095ff;  font-weight: bold;
}
.java_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.java_type {
color: rgb(128,0,0);
}
.java_operator {
color: rgb(0,0,0);
}
.java_char_literal {
color: rgb(255,0,255);
}
.java_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.java_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.java_num_literal {
color: rgb(0,0,255);
}
.java_comment {
color: rgb(147,147,147);  
}
.java_plain {
color: rgb(0,0,0);
}
.java_string_literal {
color: rgb(255,0,0);
}
.java_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="java_keyword">package</span><span class="java_plain">&#160;hu</span><span class="java_separator">.</span><span class="java_plain">krivan</span><span class="java_separator">.</span><span class="java_plain">szakkor</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;*</span><br /><span class="java_javadoc_comment">&#160;*&#160;</span><span class="java_javadoc_tag">@author</span><span class="java_javadoc_comment">&#160;balint</span><br /><span class="java_javadoc_comment">&#160;*/</span><span class="java_plain"></span><br /><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">class</span><span class="java_plain">&#160;</span><span class="java_user_type">Langford</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;n</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;perm</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;idx</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;found&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;p</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[]</span><span class="java_plain">&#160;db</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_javadoc_comment">/**</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*&#160;</span><span class="java_javadoc_tag">@param</span><span class="java_javadoc_comment">&#160;args&#160;the&#160;command&#160;line&#160;arguments</span><br /><span class="java_javadoc_comment">&#160;&#160;&#160;&#160;&#160;*/</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">public</span><span class="java_plain">&#160;</span><span class="java_keyword">static</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;main</span><span class="java_separator">(</span><span class="java_user_type">String</span><span class="java_separator">[]</span><span class="java_plain">&#160;args</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">Langford</span><span class="java_plain">&#160;l&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_user_type">Langford</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_num_literal">11</span><span class="java_plain">&#160;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;l</span><span class="java_separator">.</span><span class="java_plain">generate</span><span class="java_separator">();</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_user_type">Langford</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;p</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">this</span><span class="java_separator">.</span><span class="java_plain">p&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;p</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;n&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;p</span><span class="java_operator">*</span><span class="java_num_literal">2</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;perm&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[</span><span class="java_plain">p</span><span class="java_operator">*</span><span class="java_num_literal">2</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;i</span><span class="java_operator">=</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">&lt;</span><span class="java_plain">perm</span><span class="java_separator">.</span><span class="java_plain">length</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;idx&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[</span><span class="java_plain">p</span><span class="java_separator">];</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;csak&#160;p&#160;darabnyi&#160;kell!</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;db&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_keyword">new</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_separator">[</span><span class="java_plain">p</span><span class="java_separator">];</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;i</span><span class="java_operator">=</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">&lt;</span><span class="java_plain">p</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;db</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">void</span><span class="java_plain">&#160;generate</span><span class="java_separator">()</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;elkezdj&uuml;k&#160;felt&ouml;lteni&#160;a&#160;perm-et.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">while</span><span class="java_separator">(</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&gt;=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_plain">&#160;</span><span class="java_operator">&amp;&amp;</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">&lt;=</span><span class="java_plain">&#160;n&#160;</span><span class="java_separator">)</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;stillGood</span><span class="java_separator">(</span><span class="java_plain">&#160;i&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;i&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;n&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;j&oacute;k&#160;vagyunk,&#160;de&#160;m&aacute;r&#160;t&uacute;ll&oacute;gunk&#160;a&#160;t&ouml;mb&ouml;n</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;ne&#160;legy&uuml;nk&#160;moh&oacute;k,&#160;hova&#160;akarunk&#160;m&eacute;g&#160;pakolni,&#160;ha&#160;m&aacute;r&#160;ez&#160;egy&#160;teljes&#160;langford&#160;permut&aacute;ci&oacute;?&#160;:)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;found</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;visszal&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;i</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">&lt;</span><span class="java_plain">&#160;p&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;ha&#160;m&eacute;g&#160;f&eacute;r&#160;ide&#160;egy&#160;nagyobbik&#160;sz&aacute;m&#160;akkor&#160;rakunk.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">!=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;db</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;elősz&ouml;r&#160;az&#160;ott&#160;l&eacute;vő&#160;sz&aacute;m&#160;darabsz&aacute;m&aacute;t&#160;cs&ouml;kkentj&uuml;k</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">do</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;elkezdj&uuml;k&#160;n&ouml;velgetni&#160;a&#160;sz&aacute;mot,&#160;ameddig&#160;kell&#160;(ha&#160;2&#160;van&#160;belőle,&#160;akkor&#160;megy&uuml;nk&#160;tov&aacute;bb)</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">&gt;</span><span class="java_plain">&#160;p&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">while</span><span class="java_separator">(</span><span class="java_plain">&#160;db</span><span class="java_separator">[</span><span class="java_plain">perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_num_literal">2</span><span class="java_plain">&#160;</span><span class="java_separator">);</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;vagy&#160;siker&uuml;lt&#160;betenni&#160;sz&aacute;mot,&#160;vagy&#160;nem.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">&gt;</span><span class="java_plain">&#160;p&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;nem&#160;tudunk&#160;az&#160;adott&#160;helyre&#160;tenni&#160;semmi&#160;&uacute;jat,&#160;akkor&#160;visszal&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;t&ouml;r&ouml;lj&uuml;k&#160;a&#160;permut&aacute;ci&oacute;b&oacute;l&#160;a&#160;sz&aacute;mot</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;i</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;visszal&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;sikeresen&#160;pakoltunk&#160;a&#160;helyre</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;db</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;n&ouml;velj&uuml;k&#160;a&#160;darabsz&aacute;mot</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;i</span><span class="java_operator">++</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;tov&aacute;bbl&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;nem&#160;tehető&#160;ide&#160;nagyobb&#160;sz&aacute;m,&#160;mert&#160;ez&#160;a&#160;maximum.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;db</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;cs&ouml;kkentj&uuml;k&#160;a&#160;darabsz&aacute;mot</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;t&ouml;r&ouml;lj&uuml;k&#160;a&#160;permut&aacute;ci&oacute;b&oacute;l&#160;a&#160;sz&aacute;mot</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;i</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;visszal&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;nem&#160;lehet&#160;ebből&#160;langfordot&#160;&ouml;sszehozni,&#160;ne&#160;szenvedj&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;i</span><span class="java_operator">--</span><span class="java_separator">;</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;visszal&eacute;p&uuml;nk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;v&eacute;gig&#160;j&aacute;rtuk&#160;az&#160;utunkat.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_user_type">System</span><span class="java_separator">.</span><span class="java_plain">out</span><span class="java_separator">.</span><span class="java_plain">println</span><span class="java_separator">(</span><span class="java_plain">found</span><span class="java_operator">/</span><span class="java_num_literal">2</span><span class="java_separator">);</span><span class="java_plain">&#160;</span><span class="java_comment">//&#160;mindent&#160;2x&#160;sz&aacute;moltunk,&#160;ez&eacute;rt&#160;csak&#160;a&#160;fel&eacute;t&#160;&iacute;rjuk&#160;ki.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_keyword">private</span><span class="java_plain">&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;stillGood</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;b</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;k&eacute;rd&eacute;s,&#160;hogy&#160;az&#160;első&#160;i&#160;elem&#160;eddig&#160;j&oacute;-e?</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;itt&#160;van&#160;egy&#160;permut&aacute;ci&oacute;nk&#160;amit&#160;vizsg&aacute;lnunk&#160;kell.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_type">boolean</span><span class="java_plain">&#160;cool&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">true</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_type">int</span><span class="java_plain">&#160;i</span><span class="java_operator">=</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">&lt;</span><span class="java_plain">p</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;idx</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">for</span><span class="java_separator">(</span><span class="java_type">int</span><span class="java_plain">&#160;i</span><span class="java_operator">=</span><span class="java_num_literal">0</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">&lt;</span><span class="java_plain">b</span><span class="java_separator">;</span><span class="java_plain">&#160;i</span><span class="java_operator">++</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;megy&uuml;nk&#160;v&eacute;gig&#160;a&#160;sz&aacute;mokon,&#160;de&#160;csak&#160;b-ig,&#160;ameddig&#160;ok&eacute;s&#160;a&#160;dolog</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;idx</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;idx</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;i</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;olyan&#160;sz&aacute;mot&#160;tal&aacute;lunk,&#160;ami&#160;m&aacute;r&#160;volt&#160;egyszer.</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;idx&#160;k&uuml;l&ouml;nbs&eacute;g:</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">if</span><span class="java_separator">(</span><span class="java_plain">&#160;</span><span class="java_separator">(</span><span class="java_plain">&#160;i</span><span class="java_operator">-</span><span class="java_plain">idx</span><span class="java_separator">[</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">]</span><span class="java_operator">-</span><span class="java_num_literal">1</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_operator">==</span><span class="java_plain">&#160;perm</span><span class="java_separator">[</span><span class="java_plain">i</span><span class="java_separator">]</span><span class="java_plain">&#160;</span><span class="java_separator">)</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_comment">//&#160;rendben&#160;vagyunk</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain">&#160;</span><span class="java_keyword">else</span><span class="java_plain">&#160;</span><span class="java_separator">{</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cool&#160;</span><span class="java_operator">=</span><span class="java_plain">&#160;</span><span class="java_other_literal">false</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">break</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="java_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="java_keyword">return</span><span class="java_plain">&#160;cool</span><span class="java_separator">;</span><span class="java_plain"></span><br /><span class="java_plain">&#160;&#160;&#160;&#160;</span><span class="java_separator">}</span><span class="java_plain"></span><br /><span class="java_plain"></span><br /><span class="java_separator">}</span><span class="java_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0809/02ora/langford/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2009-11-07 23:21:21
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
