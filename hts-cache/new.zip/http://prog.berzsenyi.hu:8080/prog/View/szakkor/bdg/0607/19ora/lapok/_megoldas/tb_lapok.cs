<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs">tb_lapok.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_selected">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_normal">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=2112';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=2113';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=2115';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=2116';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=2118';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=2119';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=2120';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=2125';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=2124';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=2126';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=2127';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=2128';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=2129';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=1565';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=2131';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=2132';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=2133';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=2134';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=2137';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=2138';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=1632';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=1650';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=2141';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=2142';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=2143';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=2144';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=2145';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0607/19ora">19. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="2112">1. óra</option><option  value="2113">2. óra</option><option  value="2115">3. óra</option><option  value="2116">4. óra</option><option  value="2118">5. óra</option><option  value="2119">6. óra</option><option  value="2120">7. óra</option><option  value="2125">8. óra</option><option  value="2124">9. óra</option><option  value="2126">10. óra</option><option  value="2127">11. óra</option><option  value="2128">12. óra</option><option  value="2129">13. óra</option><option  value="1565">14. óra</option><option  value="2131">15. óra</option><option  value="2132">16. óra</option><option  value="2133">17. óra</option><option  value="2134">18. óra</option><option  selected="selected"  value="2137">19. óra</option><option  value="2138">20. óra</option><option  value="1632">21. óra</option><option  value="1650">22. óra</option><option  value="2141">23. óra</option><option  value="2142">24. óra</option><option  value="2143">25. óra</option><option  value="2144">26. óra</option><option  value="2145">27. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 27) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=1677';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=1701';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=1535';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=1390';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=1674';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=1582';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=1312';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=1396';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=1584';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=1615';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=1633';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=1522';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=1568';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=1688';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=1573';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=1540';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=1352';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=1592';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=1383';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=1374';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=1456';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=1513';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=1661';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=1508';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=1666';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=1468';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=1421';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=1656';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=1682';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0607/19ora/lapok">Lapok</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="1677">Banda</option><option  value="1701">Connect</option><option  value="1535">Csapatok</option><option  value="1390">DNS</option><option  value="1674">DNS2</option><option  value="1582">Doboz</option><option  value="1312">Dominófedés</option><option  value="1396">Egyiptomi törtek</option><option  value="1584">Fal</option><option  value="1615">Hajók</option><option  value="1633">Háromszög</option><option  value="1522">Hatszög</option><option  value="1568">Kábel</option><option  value="1688">Kamionok</option><option  value="1573">Két út</option><option  value="1540">Konténer</option><option  value="1352">Lámpák</option><option  selected="selected"  value="1592">Lapok</option><option  value="1383">NYÁK</option><option  value="1374">Osztály</option><option  value="1456">Parcellák</option><option  value="1513">Parcellák 2.</option><option  value="1661">Pontok</option><option  value="1508">Régiók</option><option  value="1666">Sakk</option><option  value="1468">Színház</option><option  value="1421">Születésnap</option><option  value="1656">Találka</option><option  value="1682">Túlélő verseny</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 29) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0607/19ora">19. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0607/19ora/lapok">Lapok</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607">2006/2007</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/19ora">19. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/19ora/lapok">Lapok</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs">tb_lapok.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas/tb_lapok.cs">tb_lapok.cs</a>
        
            (<a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="1628" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: utf-8</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: utf-8 <br />
        
        Méret: 2 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_plain">﻿</span><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">IO</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;Lapok</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">struct</span><span class="csharp_plain">&#160;Lap</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;bal</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;jobb</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;fent</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;lent</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;Lap</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;bal</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;jobb</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;fent</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;lent</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">bal&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;bal</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">jobb&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;jobb</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">fent&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;fent</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">this</span><span class="csharp_separator">.</span><span class="csharp_plain">lent&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;lent</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Bal</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;bal</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Jobb</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;jobb</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Fent</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;fent</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Lent</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;get&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;lent</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">bool</span><span class="csharp_plain">&#160;Tartalmaz</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;x&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;bal&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;x&#160;</span><span class="csharp_operator">&lt;=</span><span class="csharp_plain">&#160;jobb&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;y&#160;</span><span class="csharp_operator">&gt;=</span><span class="csharp_plain">&#160;fent&#160;</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">&#160;y&#160;</span><span class="csharp_operator">&lt;=</span><span class="csharp_plain">&#160;lent</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;LapHalmaz</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;lapSzam&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Lap</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;lapok</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;LapHalmaz</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;maxLapSzam</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lapok&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Lap</span><span class="csharp_separator">[</span><span class="csharp_plain">maxLapSzam</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;LapotHozzaad</span><span class="csharp_separator">(</span><span class="csharp_plain">Lap&#160;lap</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">lapSzam</span><span class="csharp_operator">++</span><span class="csharp_separator">]</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;lap</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">private</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;Egymason</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;tartalmazok&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;lapSzam</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Tartalmaz</span><span class="csharp_separator">(</span><span class="csharp_plain">x</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y</span><span class="csharp_separator">))</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;tartalmazok</span><span class="csharp_operator">++</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;tartalmazok</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;MaxEgymason</span><span class="csharp_separator">()</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;max&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;lapSzam</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;j&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;lapSzam</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;j</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;egymason1&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Egymason</span><span class="csharp_separator">(</span><span class="csharp_plain">lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Bal</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">j</span><span class="csharp_separator">].</span><span class="csharp_plain">Fent</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;egymason2&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Egymason</span><span class="csharp_separator">(</span><span class="csharp_plain">lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">i</span><span class="csharp_separator">].</span><span class="csharp_plain">Jobb</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;lapok</span><span class="csharp_separator">[</span><span class="csharp_plain">j</span><span class="csharp_separator">].</span><span class="csharp_plain">Lent</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">egymason1&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;max</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;max&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;egymason1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">egymason2&#160;</span><span class="csharp_operator">&gt;</span><span class="csharp_plain">&#160;max</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;max&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;egymason2</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;max</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Program</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">const</span><span class="csharp_plain">&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;Sorszam&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;1&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">const</span><span class="csharp_plain">&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;InputFile&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;lapok&quot;</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;Sorszam&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;.be&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">const</span><span class="csharp_plain">&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;OutputFile&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;lapok&quot;</span><span class="csharp_plain">&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;Sorszam&#160;</span><span class="csharp_operator">+</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;.ki&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">private</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;LapHalmaz&#160;Beolvas</span><span class="csharp_separator">()</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">StreamReader&#160;reader&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamReader</span><span class="csharp_separator">(</span><span class="csharp_plain">InputFile</span><span class="csharp_separator">))</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;n&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">reader</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">());</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;LapHalmaz&#160;halmaz&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;LapHalmaz</span><span class="csharp_separator">(</span><span class="csharp_plain">n</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i&#160;</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">&#160;n</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;i</span><span class="csharp_operator">++</span><span class="csharp_separator">)</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;sor&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;reader</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">().</span><span class="csharp_plain">Split</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x1&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y1&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;x2&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">2</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;y2&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_num_literal">3</span><span class="csharp_separator">]);</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;halmaz</span><span class="csharp_separator">.</span><span class="csharp_plain">LapotHozzaad</span><span class="csharp_separator">(</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;Lap</span><span class="csharp_separator">(</span><span class="csharp_plain">x1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;x2</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;y2</span><span class="csharp_separator">));</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">return</span><span class="csharp_plain">&#160;halmaz</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;LapHalmaz&#160;halmaz&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;Beolvas</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">(</span><span class="csharp_plain">StreamWriter&#160;writer&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamWriter</span><span class="csharp_separator">(</span><span class="csharp_plain">OutputFile</span><span class="csharp_separator">))</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;writer</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">halmaz</span><span class="csharp_separator">.</span><span class="csharp_plain">MaxEgymason</span><span class="csharp_separator">());</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0607/19ora/lapok/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Tihanyi Bal&aacute;zs;
        utolsó módosítás:
        2009-11-07 23:19:07
        (Tihanyi Bal&aacute;zs)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
