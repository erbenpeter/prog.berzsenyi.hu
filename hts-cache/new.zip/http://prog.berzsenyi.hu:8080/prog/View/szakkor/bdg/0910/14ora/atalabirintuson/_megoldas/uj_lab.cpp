<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp">uj_lab.cpp</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_selected">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=4077';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=4162';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=4196';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=4219';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=4225';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=4244';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=4258';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=4259';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=4288';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=4312';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=4406';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=4431';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=4466';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=4507';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=4520';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=4634';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=4656';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=4712';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=4734';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=4754';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=4783';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=4786';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=4947';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=4976';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=4987';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5006';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5013';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5021';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=5096';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="4077">1. óra</option><option  value="4162">2. óra</option><option  value="4196">3. óra</option><option  value="4219">4. óra</option><option  value="4225">5. óra</option><option  value="4244">6. óra</option><option  value="4258">7. óra</option><option  value="4259">8. óra</option><option  value="4288">9. óra</option><option  value="4312">10. óra</option><option  value="4406">11. óra</option><option  value="4431">12. óra</option><option  value="4466">13. óra</option><option  selected="selected"  value="4507">14. óra</option><option  value="4520">15. óra</option><option  value="4634">16. óra</option><option  value="4656">17. óra</option><option  value="4712">18. óra</option><option  value="4734">19. óra</option><option  value="4754">20. óra</option><option  value="4783">21. óra</option><option  value="4786">22. óra</option><option  value="4947">23. óra</option><option  value="4976">24. óra</option><option  value="4987">25. óra</option><option  value="5006">26. óra</option><option  value="5013">27. óra</option><option  value="5021">28. óra</option><option  value="5096">29. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 29) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=4197';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=4163';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=4123';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=4755';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=4511';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=4439';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=4606';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5014';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=4617';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=4407';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=4527';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5007';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=4282';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=4948';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=4522';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=4279';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=4657';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=4228';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=4313';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=4735';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=4988';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=4977';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=4458';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=4245';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=4615';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=4787';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=4714';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="4197">AgyKacsa</option><option  value="4163">Idegen nyelv</option><option  value="4123">Idegen számok</option><option  value="4755">Fordulj mindig balra</option><option  selected="selected"  value="4511">Át a labirintuson</option><option  value="4439">Kevin Bacon játék</option><option  value="4606">Futár</option><option  value="5014">Sokszög háromszögelése</option><option  value="4617">Járdakövezés</option><option  value="4407">Járvány</option><option  value="4527">Játék</option><option  value="5007">Kert</option><option  value="4282">Kömal fórum feladat</option><option  value="4948">Lovagok és lókötők</option><option  value="4522">Műhold</option><option  value="4279">8 királynő probléma</option><option  value="4657">Pályázatok</option><option  value="4228">Pataki-probléma</option><option  value="4313">15-ös játék</option><option  value="4735">Robot</option><option  value="4988">Selejtező forduló</option><option  value="4977">Bevásárlás</option><option  value="4458">Szójáték</option><option  value="4245">Üdvözlet</option><option  value="4615">Ütemezés</option><option  value="4787">Vasút</option><option  value="4714">Vízgyűjtők</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 27) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910">2009/2010</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp">uj_lab.cpp</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/uj_lab.cpp">uj_lab.cpp</a>
        
            (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="4611" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: us-ascii</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: us-ascii <br />
        
        Méret: 9 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.cpp_preproc {
color: purple;
}
.cpp_doxygen_comment {
color: rgb(147,147,147); background-color: rgb(247,247,247);  
}
.cpp_doxygen_tag {
color: rgb(147,147,147); background-color: rgb(247,247,247); font-style: italic; font-weight: bold;
}
.cpp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_user_type {
color: #0095ff;  font-weight: bold;
}
.cpp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.cpp_type {
color: rgb(128,0,0);
}
.cpp_operator {
color: rgb(0,0,0);
}
.cpp_char_literal {
color: rgb(255,0,255);
}
.cpp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.cpp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.cpp_num_literal {
color: rgb(0,0,255);
}
.cpp_comment {
color: rgb(147,147,147);  
}
.cpp_plain {
color: rgb(0,0,0);
}
.cpp_string_literal {
color: rgb(255,0,0);
}
.cpp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="cpp_comment">/*</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;Informatika:&#160;algoritmus&#160;szakkor</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;Feladat:&#160;at&#160;a&#160;labirintuson</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;Forras:&#160;http://prog.berzsenyi.hu:8080/prog/View/szakkor/bdg/0910/14ora/atalabirintuson</span><br /><span class="cpp_comment">&#160;&#160;&#160;&#160;Uray&#160;M.&#160;Janos,&#160;2010.&#160;januar&#160;5.</span><br /><span class="cpp_comment">*/</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#include</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">stdio</span><span class="cpp_separator">.</span><span class="cpp_plain">h</span><span class="cpp_operator">&gt;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;MaxSize&#160;</span><span class="cpp_num_literal">257</span><span class="cpp_plain"></span><br /><span class="cpp_preproc">#define</span><span class="cpp_plain">&#160;MaxLen&#160;</span><span class="cpp_num_literal">65025</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_keyword">typedef</span><span class="cpp_plain">&#160;</span><span class="cpp_type">unsigned</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;byte</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_keyword">class</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_keyword">class</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Ut&#160;osztaly</span><br /><span class="cpp_keyword">class</span><span class="cpp_plain">&#160;cRoute&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">private</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;bejart&#160;ut&#160;hossza</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;bejart&#160;ut&#160;lepesei</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">enum</span><span class="cpp_plain">&#160;eStep&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S_Forward</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;</span><span class="cpp_comment">//&#160;elore</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S_Left</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;balra</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;S_Right&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;jobbra</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">MaxLen</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">public</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;Init&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;GetLen&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;Push&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eStep</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;PushForward&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">Push</span><span class="cpp_separator">(</span><span class="cpp_plain">S_Forward</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;PushLeft&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">Push</span><span class="cpp_separator">(</span><span class="cpp_plain">S_Left</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;PushRight&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">Push</span><span class="cpp_separator">(</span><span class="cpp_plain">S_Right</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;eStep&#160;ChangeDirection&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eStep</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;Simplify&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;MarkInLab&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cLab&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;PrintToFile&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">FILE&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">};</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Labirintus&#160;osztaly</span><br /><span class="cpp_keyword">class</span><span class="cpp_plain">&#160;cLab&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">private</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;labirintus&#160;merete&#160;(a&#160;kulso&#160;falakat&#160;is&#160;szamolva)</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;labirintus&#160;elemeit&#160;tarolo&#160;ketdimenzios&#160;tomb</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">enum</span><span class="cpp_plain">&#160;eField&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;F_Space</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;ut</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;F_Wall</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;fal</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;F_Footprint</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;jart&#160;ut</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;Field</span><span class="cpp_separator">[</span><span class="cpp_plain">MaxSize</span><span class="cpp_separator">][</span><span class="cpp_plain">MaxSize</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;ut</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;cRoute&#160;Route</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">public</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Iranyok</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">enum</span><span class="cpp_plain">&#160;eDir&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D_Right</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;jobbra</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D_Up</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;fel</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D_Left</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;balra</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;D_Down&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;le</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">};</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;Run&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;Read&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;Write&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">static</span><span class="cpp_plain">&#160;eDir&#160;DirTurnLeft&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eDir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">static</span><span class="cpp_plain">&#160;eDir&#160;DirTurnRight&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eDir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">static</span><span class="cpp_plain">&#160;eDir&#160;DirTurnBack&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eDir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">static</span><span class="cpp_plain">&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;MoveDir&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;SetField&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eField</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;SetFieldSpace&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">SetField</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F_Space</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;SetFieldWall&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">SetField</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;SetFieldFootprint&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain">SetField</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F_Footprint</span><span class="cpp_separator">);}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;eField&#160;GetField&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;eField&#160;GetFieldDir&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;Start&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;Exit&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;DeleteFootprints&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;BuildLeftHandRoute&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;BuildShortestRoute&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">};</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">int</span><span class="cpp_plain">&#160;main&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;AN</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;Args&#160;</span><span class="cpp_separator">[])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;cLab&#160;Lab</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">AN&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">4</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">Run</span><span class="cpp_separator">(</span><span class="cpp_plain">Args</span><span class="cpp_separator">[</span><span class="cpp_num_literal">1</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;Args</span><span class="cpp_separator">[</span><span class="cpp_num_literal">2</span><span class="cpp_separator">],</span><span class="cpp_plain">&#160;Args</span><span class="cpp_separator">[</span><span class="cpp_num_literal">3</span><span class="cpp_separator">]);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Az&#160;ut&#160;nullazasa</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">Init&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Len&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Az&#160;ut&#160;vegere&#160;ir&#160;egy&#160;adott&#160;lepest</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">Push&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">eStep&#160;S</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Len&#160;</span><span class="cpp_operator">&gt;=</span><span class="cpp_plain">&#160;MaxLen</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">Len</span><span class="cpp_operator">++</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;S</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Lepes&#160;iranyanak&#160;megforditasa</span><br /><span class="cpp_plain">cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">eStep&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">ChangeDirection&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">eStep&#160;Step</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S_Right</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;S_Left</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S_Left</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;S_Right</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;zsakutcak&#160;levagasa</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">Simplify&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Right&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;bChange</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;levagas&#160;ugy&#160;tortenik,&#160;hogy&#160;a&#160;Step[]&#160;tombot&#160;lemasolja&#160;onmagara&#160;ugy,&#160;hogy&#160;kihagyja&#160;a&#160;zsakutcakat.&#160;I&#160;jelenti&#160;a&#160;tomb&#160;forras-indexet,&#160;J&#160;pedig&#160;a&#160;cel-indexet&#160;a&#160;masolasnal.</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Ha&#160;talal&#160;egy&#160;visszafordulast,&#160;akkor&#160;megnezi,&#160;hogy&#160;milyen&#160;mely&#160;a&#160;zsakutca,&#160;es&#160;annak&#160;megfeleloen&#160;allitja&#160;be&#160;az&#160;uj&#160;I&#160;es&#160;J&#160;ertekeket.</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Egymast&#160;koveto&#160;jobbra&#160;fordulasok&#160;szamlalasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S_Right</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Right</span><span class="cpp_operator">++</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Right&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Ha&#160;talalt&#160;ket&#160;jobbra&#160;fordulast&#160;egymas&#160;utan&#160;(azaz&#160;visszafordulast),&#160;akkor&#160;ott&#160;zsakutca&#160;van</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Right&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;bChange&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">true</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Zsakutca&#160;melysegenek&#160;meghatarozasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">K&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">true</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;K</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Step[I&#160;+&#160;K]:&#160;A&#160;visszafordulas&#160;utani&#160;K.&#160;lepes</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Step[J&#160;-&#160;K&#160;-&#160;1]:&#160;A&#160;visszafordulas&#160;elotti&#160;K.&#160;lepes&#160;(a&#160;-1&#160;a&#160;kettos&#160;jobbra&#160;fordulas&#160;miatt&#160;van)</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Ha&#160;ugy&#160;talalja,&#160;hogy&#160;a&#160;zsakutca&#160;veget&#160;ert,&#160;akkor&#160;kilep&#160;a&#160;ciklusbol</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S_Forward</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;S_Forward</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;S_Forward</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;bChange&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">false</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;K</span><span class="cpp_operator">++</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;180&#160;fokos&#160;iranyvaltozas&#160;miatt&#160;a&#160;zsakutcahoz&#160;kapcsolodo&#160;iranyok&#160;megforditasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">bChange</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;ChangeDirection</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">]);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;ChangeDirection</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;K&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">]);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Zsakutca&#160;torlese</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;I&#160;</span><span class="cpp_operator">+=</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;J&#160;</span><span class="cpp_operator">-=</span><span class="cpp_plain">&#160;K</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_operator">++</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;ut&#160;hosszanak&#160;megvaltoztatasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Len&#160;</span><span class="cpp_operator">-=</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Az&#160;ut&#160;jelolese&#160;egy&#160;adott&#160;labirintusban</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">MarkInLab&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cLab&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;Lab</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;Dir</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">Start</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">SetFieldFootprint</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Forward</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">MoveDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">SetFieldFootprint</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Left</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">DirTurnLeft</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Right</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;Lab</span><span class="cpp_separator">.</span><span class="cpp_plain">DirTurnRight</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Az&#160;ut&#160;kiirasa&#160;egy&#160;adott&#160;fajlba&#160;a&#160;megadott&#160;formatumban</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cRoute</span><span class="cpp_operator">::</span><span class="cpp_plain">PrintToFile&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">FILE&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Len</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Step</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Forward</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;E&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Left</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;B&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;S_Right</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;J&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;\n&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;feladatok&#160;megoldasa</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">Run&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;In</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;OutA</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;OutB</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Beolvasas</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Read</span><span class="cpp_separator">(</span><span class="cpp_plain">In</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;balkezes&#160;feladat&#160;megoldasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;BuildLeftHandRoute</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">MarkInLab</span><span class="cpp_separator">(</span><span class="cpp_operator">*</span><span class="cpp_keyword">this</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Write</span><span class="cpp_separator">(</span><span class="cpp_plain">OutB</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;legrovidebb&#160;ut&#160;megtalalasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;DeleteFootprints</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;BuildShortestRoute</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">MarkInLab</span><span class="cpp_separator">(</span><span class="cpp_operator">*</span><span class="cpp_keyword">this</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Write</span><span class="cpp_separator">(</span><span class="cpp_plain">OutA</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;labirintus&#160;beolvasasa</span><br /><span class="cpp_type">bool</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">Read&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;FN</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;FILE&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;F&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;fopen</span><span class="cpp_separator">(</span><span class="cpp_plain">FN</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;r&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">F&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;NULL</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">false</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;Str</span><span class="cpp_separator">[</span><span class="cpp_plain">MaxSize&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">];</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Labirintus&#160;meretenek&#160;beolvasasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fscanf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%d\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">Size</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Size&#160;</span><span class="cpp_operator">&gt;</span><span class="cpp_plain">&#160;MaxSize</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fclose</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">false</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;kulso&#160;falakat&#160;is&#160;beleszamitjuk</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Size&#160;</span><span class="cpp_operator">+=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Sorok&#160;olvasasa&#160;(az&#160;utolsot&#160;be&#160;sem&#160;olvassa,&#160;mert&#160;az&#160;mindig&#160;ugyanaz)</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Sor&#160;beolvasasa&#160;stringkent</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fgets</span><span class="cpp_separator">(</span><span class="cpp_plain">Str</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;MaxSize&#160;</span><span class="cpp_operator">+</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;sorok&#160;szetbontasa&#160;a&#160;'Field'&#160;tombbe</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Str</span><span class="cpp_separator">[</span><span class="cpp_plain">J</span><span class="cpp_separator">])</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;</span><span class="cpp_char_literal">'&#160;'</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;SetFieldSpace</span><span class="cpp_separator">(</span><span class="cpp_plain">J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;</span><span class="cpp_char_literal">'#'</span><span class="cpp_operator">:</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;SetFieldWall</span><span class="cpp_separator">(</span><span class="cpp_plain">J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fclose</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">true</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;feladat&#160;megoldasanak&#160;kiirasa</span><br /><span class="cpp_type">bool</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">Write&#160;</span><span class="cpp_separator">(</span><span class="cpp_keyword">const</span><span class="cpp_plain">&#160;</span><span class="cpp_type">char</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;FN</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;FILE&#160;</span><span class="cpp_operator">*</span><span class="cpp_plain">&#160;F&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;fopen</span><span class="cpp_separator">(</span><span class="cpp_plain">FN</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;w&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">F&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;NULL</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">false</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;uthossz&#160;kiirasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;%d\n&quot;</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">GetLen</span><span class="cpp_separator">());</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;ut&#160;kiirasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PrintToFile</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;A&#160;labirintus&#160;kirajzolasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">GetField</span><span class="cpp_separator">(</span><span class="cpp_plain">J</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">))</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;F_Space</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fputc</span><span class="cpp_separator">(</span><span class="cpp_char_literal">'&#160;'</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fputc</span><span class="cpp_separator">(</span><span class="cpp_char_literal">'#'</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;F_Footprint</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;fputc</span><span class="cpp_separator">(</span><span class="cpp_char_literal">'.'</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">);</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">break</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;fprintf</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_string_literal">&quot;\n&quot;</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;fclose</span><span class="cpp_separator">(</span><span class="cpp_plain">F</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;</span><span class="cpp_bool_literal">true</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Irany&#160;balra&#160;forditasa</span><br /><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">DirTurnLeft&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Irany&#160;jobbra&#160;forditasa</span><br /><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">DirTurnRight&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Irany&#160;megforditasa</span><br /><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">DirTurnBack&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eDir&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Egy&#160;koordinata&#160;mozgatasa&#160;adott&#160;iranyba</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">MoveDir&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">switch</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;X</span><span class="cpp_operator">++</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Up</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;Y</span><span class="cpp_operator">--</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Left</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;X</span><span class="cpp_operator">--</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">case</span><span class="cpp_plain">&#160;D_Down</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;Y</span><span class="cpp_operator">++</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">return</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Adott&#160;mezo&#160;beallitasa</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">SetField&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eField&#160;F</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">X&#160;</span><span class="cpp_operator">&gt;=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;Y&#160;</span><span class="cpp_operator">&gt;=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Field</span><span class="cpp_separator">[</span><span class="cpp_plain">Y</span><span class="cpp_separator">][</span><span class="cpp_plain">X</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;F</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;labirintus&#160;adott&#160;koordinataju&#160;mezojenek&#160;visszaadasa</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eField&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">GetField&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;X&#160;</span><span class="cpp_operator">&gt;=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;X&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;Y&#160;</span><span class="cpp_operator">&gt;=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;Y&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size&#160;</span><span class="cpp_operator">?</span><span class="cpp_plain">&#160;Field</span><span class="cpp_separator">[</span><span class="cpp_plain">Y</span><span class="cpp_separator">][</span><span class="cpp_plain">X</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">:</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;labirintus&#160;adott&#160;mezojetol&#160;adott&#160;iranyban&#160;levo&#160;mezo&#160;visszaadasa</span><br /><span class="cpp_plain">cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">eField&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">GetFieldDir&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;MoveDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;GetField</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;kezdohely&#160;es&#160;irany&#160;beallitasa</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;</span><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">Start&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;eDir&#160;</span><span class="cpp_operator">&amp;</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;X&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Y&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;D_Right</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Megnezi,&#160;hogy&#160;az&#160;adott&#160;hely&#160;a&#160;labirintus&#160;kijarata-e</span><br /><span class="cpp_keyword">inline</span><span class="cpp_plain">&#160;</span><span class="cpp_type">bool</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">Exit&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">return</span><span class="cpp_plain">&#160;X&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;Size&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">1</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">&amp;&amp;</span><span class="cpp_plain">&#160;Y&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;Size&#160;</span><span class="cpp_operator">-</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">2</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;Utjelzes&#160;torlese</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">DeleteFootprints&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;I</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;J</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">I&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;I</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">for</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">J&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;</span><span class="cpp_num_literal">0</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J&#160;</span><span class="cpp_operator">&lt;</span><span class="cpp_plain">&#160;Size</span><span class="cpp_separator">;</span><span class="cpp_plain">&#160;J</span><span class="cpp_operator">++</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">Field</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">][</span><span class="cpp_plain">J</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">==</span><span class="cpp_plain">&#160;F_Footprint</span><span class="cpp_separator">)</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Field</span><span class="cpp_separator">[</span><span class="cpp_plain">I</span><span class="cpp_separator">][</span><span class="cpp_plain">J</span><span class="cpp_separator">]</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;F_Space</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_comment">//&#160;A&#160;balkezes&#160;feladat&#160;megoldasa</span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">BuildLeftHandRoute&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_type">int</span><span class="cpp_plain">&#160;X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;eDir&#160;Dir</span><span class="cpp_separator">;</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Start</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Ut&#160;nullazasa</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">Init</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Addig&#160;tart&#160;a&#160;ciklus,&#160;amig&#160;a&#160;kijarathoz&#160;nem&#160;ert&#160;(ez&#160;feltetelezi,&#160;hogy&#160;a&#160;feladatnak&#160;van&#160;megoldasa)</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">while</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_operator">!</span><span class="cpp_plain">Exit</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">))</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Az&#160;egyes&#160;iranyok&#160;vegignezese</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">GetFieldDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;DirTurnLeft</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">))</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Balra&#160;lehet&#160;menni:&#160;balra&#160;fordulunk</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;DirTurnLeft</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PushLeft</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">GetFieldDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Elore&#160;lehet&#160;menni:&#160;nem&#160;fordulunk</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">if</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">(</span><span class="cpp_plain">GetFieldDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;DirTurnRight</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">))</span><span class="cpp_plain">&#160;</span><span class="cpp_operator">!=</span><span class="cpp_plain">&#160;F_Wall</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Jobbra&#160;lehet&#160;menni:&#160;jobbra&#160;fordulunk</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;DirTurnRight</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PushRight</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain">&#160;</span><span class="cpp_keyword">else</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Csak&#160;vissza&#160;lehet&#160;menni:&#160;ketszer&#160;jobbra&#160;fordulunk</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Dir&#160;</span><span class="cpp_operator">=</span><span class="cpp_plain">&#160;DirTurnBack</span><span class="cpp_separator">(</span><span class="cpp_plain">Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PushRight</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PushRight</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="cpp_comment">//&#160;Elorelepunk&#160;az&#160;uj&#160;iranyba</span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;MoveDir</span><span class="cpp_separator">(</span><span class="cpp_plain">X</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Y</span><span class="cpp_separator">,</span><span class="cpp_plain">&#160;Dir</span><span class="cpp_separator">);</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">PushForward</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;</span><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /><span class="cpp_plain"></span><br /><span class="cpp_type">void</span><span class="cpp_plain">&#160;cLab</span><span class="cpp_operator">::</span><span class="cpp_plain">BuildShortestRoute&#160;</span><span class="cpp_separator">(</span><span class="cpp_type">void</span><span class="cpp_separator">)</span><span class="cpp_plain">&#160;</span><span class="cpp_separator">{</span><span class="cpp_plain"></span><br /><span class="cpp_plain">&#160;&#160;&#160;&#160;Route</span><span class="cpp_separator">.</span><span class="cpp_plain">Simplify</span><span class="cpp_separator">();</span><span class="cpp_plain"></span><br /><span class="cpp_separator">}</span><span class="cpp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2010-01-17 21:20:51
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
