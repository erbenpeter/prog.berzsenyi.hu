<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" >

<html xmlns="http://www.w3.org/1999/xhtml"> 
    <head>
        <title>Informatika gyűjtemény</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        


<script type="text/javascript" src="/prog/js/tatab.js" ></script>
    

<script type="text/javascript">
    
    window.onload = function() {

        

        return true;
    }
</script>

    <script type="text/javascript" src="/prog/js/latex/LaTeXMathML.js" ></script>

        



<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/unsorted.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/system/tables.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/view.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/common/doc.lists.css"/>


<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/doc.css"/>
<link rel="stylesheet" type="text/css" media="screen, print" href="/prog/css/screen/view.css"/>



        

    </head>
    <body>
        
            
            
                <div id="leftdiv">
                    







<div id="maintitle">
    <a href="/prog/View/" class="maintitle">
        Informatika gyűjtemény
    </a>
</div>

<div id="leftpanel">
    



<div id="favlinks">
    <a href="/prog/View/">Főoldal</a> |
    <a href="/prog/View/szakkor/bdg/1011">Algoritmus szakkör</a>
    <br />
    <a href="/prog/View/doku/info/articles">Cikkek</a> | 
    <a href="/prog/View/verseny/nttv/00table">Feladatok</a> |
    <a href="/prog/View/doku/info/projects">Projektek</a>
    <br />
    <a href="/prog/View/doku/info/contr">Készítők</a> |
    <a href="/prog/View/doku/info/links">Linkek</a>
</div>

    <div id="seacrhbox">
        <form action="/prog/Search/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs" method="post" accept-charset="UTF-8">
            <div style="text-align:left;">
                <input type="text" id="searchbox" name="stitle" value="" /><br />
            </div>
            <div style="text-align: right;">
                <input type="submit" name="submit" value="Keres" />
                <input type="submit" name="submit" value="Töröl" />
            </div>
        </form>
    </div>
    
    









    <div id="contextmenu">
        








        
            
                <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        <b><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs">ta_lab.cs</a></b><br />
        
            <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0405" class="tab_normal">2004</a><a href="/prog/View/szakkor/bdg/0506" class="tab_normal">05</a><a href="/prog/View/szakkor/bdg/0607" class="tab_normal">06</a><a href="/prog/View/szakkor/bdg/0708" class="tab_normal">07</a><a href="/prog/View/szakkor/bdg/0809" class="tab_normal">08</a><a href="/prog/View/szakkor/bdg/0910" class="tab_selected">09</a><a href="/prog/View/szakkor/bdg/1011" class="tab_normal">10</a></p>
            <div class="subnav">
                <div class="docpanel">
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_orak_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=4077';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=4162';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=4196';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=4219';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=4225';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=4244';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=4258';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=4259';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=4288';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=4312';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=4406';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=4431';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=4466';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=4507';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=4520';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=4634';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=4656';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=4712';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=4734';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=4754';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=4783';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=4786';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=4947';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=4976';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=4987';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=5006';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=5013';
        }
        if (selObj.selectedIndex == 28) {
            window.location = '/prog/Resolve?node=5021';
        }
        if (selObj.selectedIndex == 29) {
            window.location = '/prog/Resolve?node=5096';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_orak_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_orak_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_orak" onchange="JavaScript:menu_orak_jumpto(this)"><option>--&gt;LISTA</option><option  value="4077">1. óra</option><option  value="4162">2. óra</option><option  value="4196">3. óra</option><option  value="4219">4. óra</option><option  value="4225">5. óra</option><option  value="4244">6. óra</option><option  value="4258">7. óra</option><option  value="4259">8. óra</option><option  value="4288">9. óra</option><option  value="4312">10. óra</option><option  value="4406">11. óra</option><option  value="4431">12. óra</option><option  value="4466">13. óra</option><option  selected="selected"  value="4507">14. óra</option><option  value="4520">15. óra</option><option  value="4634">16. óra</option><option  value="4656">17. óra</option><option  value="4712">18. óra</option><option  value="4734">19. óra</option><option  value="4754">20. óra</option><option  value="4783">21. óra</option><option  value="4786">22. óra</option><option  value="4947">23. óra</option><option  value="4976">24. óra</option><option  value="4987">25. óra</option><option  value="5006">26. óra</option><option  value="5013">27. óra</option><option  value="5021">28. óra</option><option  value="5096">29. óra</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_orak_selObj = document.getElementById("menu_orak");
    function menu_orak_jumpFw() {
        i = menu_orak_selObj.selectedIndex;
	if (i < 29) {
            menu_orak_selObj.selectedIndex = i+1;
            menu_orak_jumpto(menu_orak_selObj);
	}
    }
    function menu_orak_jumpBw() {
        i = menu_orak_selObj.selectedIndex;
        if (i > 1) {
            menu_orak_selObj.selectedIndex = i-1;
            menu_orak_jumpto(menu_orak_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                    <script type="text/JavaScript">
//<![CDATA[
    function menu_feladatok_jumpto(selObj) {
        if (selObj.selectedIndex == 1) {
            window.location = '/prog/Resolve?node=4197';
        }
        if (selObj.selectedIndex == 2) {
            window.location = '/prog/Resolve?node=4163';
        }
        if (selObj.selectedIndex == 3) {
            window.location = '/prog/Resolve?node=4123';
        }
        if (selObj.selectedIndex == 4) {
            window.location = '/prog/Resolve?node=4755';
        }
        if (selObj.selectedIndex == 5) {
            window.location = '/prog/Resolve?node=4511';
        }
        if (selObj.selectedIndex == 6) {
            window.location = '/prog/Resolve?node=4439';
        }
        if (selObj.selectedIndex == 7) {
            window.location = '/prog/Resolve?node=4606';
        }
        if (selObj.selectedIndex == 8) {
            window.location = '/prog/Resolve?node=5014';
        }
        if (selObj.selectedIndex == 9) {
            window.location = '/prog/Resolve?node=4617';
        }
        if (selObj.selectedIndex == 10) {
            window.location = '/prog/Resolve?node=4407';
        }
        if (selObj.selectedIndex == 11) {
            window.location = '/prog/Resolve?node=4527';
        }
        if (selObj.selectedIndex == 12) {
            window.location = '/prog/Resolve?node=5007';
        }
        if (selObj.selectedIndex == 13) {
            window.location = '/prog/Resolve?node=4282';
        }
        if (selObj.selectedIndex == 14) {
            window.location = '/prog/Resolve?node=4948';
        }
        if (selObj.selectedIndex == 15) {
            window.location = '/prog/Resolve?node=4522';
        }
        if (selObj.selectedIndex == 16) {
            window.location = '/prog/Resolve?node=4279';
        }
        if (selObj.selectedIndex == 17) {
            window.location = '/prog/Resolve?node=4657';
        }
        if (selObj.selectedIndex == 18) {
            window.location = '/prog/Resolve?node=4228';
        }
        if (selObj.selectedIndex == 19) {
            window.location = '/prog/Resolve?node=4313';
        }
        if (selObj.selectedIndex == 20) {
            window.location = '/prog/Resolve?node=4735';
        }
        if (selObj.selectedIndex == 21) {
            window.location = '/prog/Resolve?node=4988';
        }
        if (selObj.selectedIndex == 22) {
            window.location = '/prog/Resolve?node=4977';
        }
        if (selObj.selectedIndex == 23) {
            window.location = '/prog/Resolve?node=4458';
        }
        if (selObj.selectedIndex == 24) {
            window.location = '/prog/Resolve?node=4245';
        }
        if (selObj.selectedIndex == 25) {
            window.location = '/prog/Resolve?node=4615';
        }
        if (selObj.selectedIndex == 26) {
            window.location = '/prog/Resolve?node=4787';
        }
        if (selObj.selectedIndex == 27) {
            window.location = '/prog/Resolve?node=4714';
        }
    }
//]]>
</script>
<div style="text-align: center;"><table class="aligner"><tr class="aligner"><td class="aligner" style="text-align: left; width: 10%; ">
<a href="JavaScript:menu_feladatok_jumpBw()">&lt;&lt;</a>&nbsp;</td><td class="aligner" style="text-align: center; width: 80%; ">
<b><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a></b></td><td class="aligner" style="text-align:right; width: 10%;">
&nbsp;<a href="JavaScript:menu_feladatok_jumpFw()">&gt;&gt;</a></td></tr></table>
<form action="not_implemented_action" method="get"><div><select style="width: 190px;" name="node" id="menu_feladatok" onchange="JavaScript:menu_feladatok_jumpto(this)"><option>--&gt;LISTA</option><option  value="4197">AgyKacsa</option><option  value="4163">Idegen nyelv</option><option  value="4123">Idegen számok</option><option  value="4755">Fordulj mindig balra</option><option  selected="selected"  value="4511">Át a labirintuson</option><option  value="4439">Kevin Bacon játék</option><option  value="4606">Futár</option><option  value="5014">Sokszög háromszögelése</option><option  value="4617">Járdakövezés</option><option  value="4407">Járvány</option><option  value="4527">Játék</option><option  value="5007">Kert</option><option  value="4282">Kömal fórum feladat</option><option  value="4948">Lovagok és lókötők</option><option  value="4522">Műhold</option><option  value="4279">8 királynő probléma</option><option  value="4657">Pályázatok</option><option  value="4228">Pataki-probléma</option><option  value="4313">15-ös játék</option><option  value="4735">Robot</option><option  value="4988">Selejtező forduló</option><option  value="4977">Bevásárlás</option><option  value="4458">Szójáték</option><option  value="4245">Üdvözlet</option><option  value="4615">Ütemezés</option><option  value="4787">Vasút</option><option  value="4714">Vízgyűjtők</option></select><br /></div><script type="text/JavaScript">
//<![CDATA[
menu_feladatok_selObj = document.getElementById("menu_feladatok");
    function menu_feladatok_jumpFw() {
        i = menu_feladatok_selObj.selectedIndex;
	if (i < 27) {
            menu_feladatok_selObj.selectedIndex = i+1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
	}
    }
    function menu_feladatok_jumpBw() {
        i = menu_feladatok_selObj.selectedIndex;
        if (i > 1) {
            menu_feladatok_selObj.selectedIndex = i-1;
            menu_feladatok_jumpto(menu_feladatok_selObj);
        }
    }
//]]>
</script>
<noscript><div><input type="submit" value="Ugrás" /></div></noscript></form></div>
                </div>
            </div>
        
        
            <div id="navpanel">
                <a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a><br />
                
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a>
                    
                    
                        (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">M.</a>)
                     <br />
                
            </div>
                
        
        
    </div>


    




    



    <!-- <a href="?page=admin&amp;a=/">Admin</a> -->
</div>

                </div>
                <!-- RIGHT -->
                <div id="rightdiv">
                    



 
 

    <p class="tabhead">
<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs" class="tab_selected_white">Nézet</a><a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs?page=print" class="tab_normal">Nyomtat</a></p>
<div id="rightbase">    
    






    <div id="navbar">
        








        
            
                <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">
                    <img src="/prog/img/up.png" alt="Egy szinttel feljebb" class="uparrow_active" />                    
                </a>
            
            
        
        
            
                
                
                    
                        
                            
                        
                        
                    
                    
                    <a href="/prog/View">Főoldal</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor">Szakkörök</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg">BDG Szakkör</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910">2009/2010</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora">14. óra</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson">Át a labirintuson</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Megoldás</a>
                
                    
                        
                        &gt;
                    
                    
                    <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs">ta_lab.cs</a>
                
            
            
        
    </div> <!-- navbar -->
    


    


 


    

    
    
        
              
        
            
            
            
            
            
                
                
                
                
                    







    
    
        






    <div style="padding: 3px; ">
        <a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas/ta_lab.cs">ta_lab.cs</a>
        
            (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Vissza</a>)
        
    </div>
    





<div class="download">
    
        
        
            Az alábbi letöltési lehetőségek közül választhatsz: (<a href="/prog/View/doku/info/downloadhelp">segítség</a>)
            <br/>

                <form action="/prog/Download">
                    <input type="hidden" name="method" value="text" />
                    <input type="hidden" name="node" value="4528" />
             
                    <table class="aligner" id="downloadtable">
                        <tr>
                            <td rowspan="2">
                                <input type="submit" value="Letöltés" style="width: 80px; height: 40px; "/>
                            </td>
                            <td>
                                Karakterkódolás:
                            </td>
                            <td>
                                <select name="encoding">
                                    <option value="null">Változatlan: us-ascii</option>
                                    <option value="utf-8">Konverzió: utf-8</option>
                                    <option value="iso8859-2">Konverzió: iso8859-2</option>
                                    <option value="ibm852">Konverzió: ibm852</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Sortörés:
                            </td>
                            <td>
                                <select name="linefeed">
                                    <option value="null">Változatlan</option>
                                    <option value="dos">Konverzió: DOS (CR+LF)</option>
                                    <option value="unix">Konverzió: UNIX (LF)</option>
                                </select>
                            </td>
                        </tr>
                    </table>
                </form>
        
    
</div>
    






    <div class="infotext" style="margin: 0px; border-left-width: 0px; border-right-width: 0px; border-bottom: 1px solid black; ">
        Típus: text/plain <br />
        
            <i>Tartalmaz szöveget</i> <br />
            Karakterkódolás: us-ascii <br />
        
        Méret: 4 KB

    </div>


    
    
        





 
<div id="fullcode" class="codetext" ><style>.csharp_directive {
color: rgb(0,147,0);
}
.csharp_other_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_user_type {
color: #0095ff;  font-weight: bold;
}
.csharp_keyword {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_char_literal {
color: rgb(255,0,255); font-weight: bold;
}
.csharp_type {
color: rgb(128,0,0);
}
.csharp_operator {
color: rgb(0,0,0);
}
.csharp_char_literal {
color: rgb(255,0,255);
}
.csharp_bool_literal {
color: rgb(0,0,0); font-weight: bold;
}
.csharp_esc_string_literal {
color: rgb(255,0,0); font-weight: bold;
}
.csharp_num_literal {
color: rgb(0,0,255);
}
.csharp_comment {
color: rgb(147,147,147);  
}
.csharp_plain {
color: rgb(0,0,0);
}
.csharp_string_literal {
color: rgb(255,0,0);
}
.csharp_separator {
color: rgb(0,0,0);
}
</style><!--  : generated by JHighlight v1.0 (http://jhighlight.dev.java.net) --><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_keyword">using</span><span class="csharp_plain">&#160;System</span><span class="csharp_separator">.</span><span class="csharp_plain">IO</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_keyword">namespace</span><span class="csharp_plain">&#160;psz_100105</span><br /><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">class</span><span class="csharp_plain">&#160;Program</span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">public</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">static</span><span class="csharp_plain">&#160;</span><span class="csharp_type">void</span><span class="csharp_plain">&#160;Main</span><span class="csharp_separator">(</span><span class="csharp_type">string</span><span class="csharp_separator">[]</span><span class="csharp_plain">&#160;args</span><span class="csharp_separator">)</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain"></span><br /><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;StreamReader&#160;sr&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamReader</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;lab05.txt&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;meret&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_type">int</span><span class="csharp_separator">.</span><span class="csharp_plain">Parse</span><span class="csharp_separator">(</span><span class="csharp_plain">sr</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">())</span><span class="csharp_operator">+</span><span class="csharp_num_literal">2</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">char</span><span class="csharp_separator">[,]</span><span class="csharp_plain">&#160;labi&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;</span><span class="csharp_type">char</span><span class="csharp_separator">[</span><span class="csharp_plain">meret</span><span class="csharp_separator">,</span><span class="csharp_plain">meret</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;a</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;b</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;sor</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">a</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sor&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;sr</span><span class="csharp_separator">.</span><span class="csharp_plain">ReadLine</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">b</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_plain">sor</span><span class="csharp_separator">[</span><span class="csharp_plain">b</span><span class="csharp_separator">];</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">((</span><span class="csharp_plain">a</span><span class="csharp_operator">==</span><span class="csharp_num_literal">0</span><span class="csharp_operator">|</span><span class="csharp_plain">b</span><span class="csharp_operator">==</span><span class="csharp_num_literal">0</span><span class="csharp_operator">|</span><span class="csharp_plain">a</span><span class="csharp_operator">==</span><span class="csharp_plain">meret-1</span><span class="csharp_operator">|</span><span class="csharp_plain">b</span><span class="csharp_operator">==</span><span class="csharp_plain">meret-1</span><span class="csharp_separator">)</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'Q'</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">bool</span><span class="csharp_plain">&#160;vaneharom</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;hanyszomszed</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">while</span><span class="csharp_separator">(</span><span class="csharp_plain">vaneharom</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;vaneharom</span><span class="csharp_operator">=</span><span class="csharp_keyword">false</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">a</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret-1</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">b</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret-1</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;hanyszomszed</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a-1</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">){</span><span class="csharp_plain">hanyszomszed</span><span class="csharp_operator">++</span><span class="csharp_separator">;};</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b-1</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">){</span><span class="csharp_plain">hanyszomszed</span><span class="csharp_operator">++</span><span class="csharp_separator">;};</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">){</span><span class="csharp_plain">hanyszomszed</span><span class="csharp_operator">++</span><span class="csharp_separator">;};</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">){</span><span class="csharp_plain">hanyszomszed</span><span class="csharp_operator">++</span><span class="csharp_separator">;};</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">hanyszomszed</span><span class="csharp_operator">==</span><span class="csharp_num_literal">3</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;vaneharom</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">char</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'j'</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;labi</span><span class="csharp_separator">[</span><span class="csharp_num_literal">0</span><span class="csharp_separator">,</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">int</span><span class="csharp_plain">&#160;pozx</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">&#160;pozy</span><span class="csharp_operator">=</span><span class="csharp_num_literal">1</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">string</span><span class="csharp_plain">&#160;ut&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_string_literal">&quot;E&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_type">bool</span><span class="csharp_plain">&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">false</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">while</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_separator">]</span><span class="csharp_operator">!=</span><span class="csharp_char_literal">'Q'</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_separator">]</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'Z'</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">lepes</span><span class="csharp_operator">==</span><span class="csharp_keyword">false</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'j'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;J&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'l'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'b'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;B&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'l'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;pozx</span><span class="csharp_operator">++</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx-1</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">lepes</span><span class="csharp_operator">==</span><span class="csharp_keyword">false</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'j'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;B&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'f'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'b'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;J&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'f'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;pozx--</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">lepes</span><span class="csharp_operator">==</span><span class="csharp_keyword">false</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'f'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;J&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'j'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'l'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;B&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'j'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;pozy</span><span class="csharp_operator">++</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy-1</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'&#160;'</span><span class="csharp_operator">&amp;&amp;</span><span class="csharp_plain">lepes</span><span class="csharp_operator">==</span><span class="csharp_keyword">false</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'f'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;B&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'b'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'l'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;J&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'b'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;pozy--</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">true</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">pozx</span><span class="csharp_separator">,</span><span class="csharp_plain">pozy</span><span class="csharp_operator">+</span><span class="csharp_num_literal">1</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'Q'</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;E&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">irany</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'l'</span><span class="csharp_separator">){</span><span class="csharp_plain">ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;B&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain">&#160;irany</span><span class="csharp_operator">=</span><span class="csharp_char_literal">'b'</span><span class="csharp_separator">;}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;pozy</span><span class="csharp_operator">++</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ut</span><span class="csharp_operator">+=</span><span class="csharp_string_literal">&quot;E&quot;</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lepes</span><span class="csharp_operator">=</span><span class="csharp_keyword">false</span><span class="csharp_separator">;</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;StreamWriter&#160;sw&#160;</span><span class="csharp_operator">=</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">new</span><span class="csharp_plain">&#160;StreamWriter</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;lab05.kiA&quot;</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sw</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">ut</span><span class="csharp_separator">.</span><span class="csharp_plain">Length</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sw</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">(</span><span class="csharp_plain">ut</span><span class="csharp_separator">);</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">a</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret</span><span class="csharp_separator">;</span><span class="csharp_plain">a</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">for</span><span class="csharp_separator">(</span><span class="csharp_plain">b</span><span class="csharp_operator">=</span><span class="csharp_num_literal">0</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">&lt;</span><span class="csharp_plain">meret</span><span class="csharp_separator">;</span><span class="csharp_plain">b</span><span class="csharp_operator">++</span><span class="csharp_separator">){</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_keyword">if</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]</span><span class="csharp_operator">==</span><span class="csharp_char_literal">'#'</span><span class="csharp_separator">){</span><span class="csharp_plain">sw</span><span class="csharp_separator">.</span><span class="csharp_plain">Write</span><span class="csharp_separator">(</span><span class="csharp_plain">labi</span><span class="csharp_separator">[</span><span class="csharp_plain">a</span><span class="csharp_separator">,</span><span class="csharp_plain">b</span><span class="csharp_separator">]);}</span><span class="csharp_plain">&#160;</span><span class="csharp_keyword">else</span><span class="csharp_plain">&#160;</span><span class="csharp_separator">{</span><span class="csharp_plain">sw</span><span class="csharp_separator">.</span><span class="csharp_plain">Write</span><span class="csharp_separator">(</span><span class="csharp_string_literal">&quot;.&quot;</span><span class="csharp_separator">);};</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sw</span><span class="csharp_separator">.</span><span class="csharp_plain">WriteLine</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sw</span><span class="csharp_separator">.</span><span class="csharp_plain">Close</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sr</span><span class="csharp_separator">.</span><span class="csharp_plain">Close</span><span class="csharp_separator">();</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_plain">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</span><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /><span class="csharp_separator">}</span><span class="csharp_plain"></span><br /></div>
    <div style="padding:3px;">
        
            (<a href="/prog/View/szakkor/bdg/0910/14ora/atalabirintuson/_megoldas">Vissza</a>)
        
    </div>
    

    

                
                
            
        
    
</div> <!-- rightbase -->
<div id="copyright">
    
        A dokumentum tulajdonosa: Erben P&eacute;ter;
        utolsó módosítás:
        2010-01-12 18:33:00
        (Erben P&eacute;ter)
        <br />
    

        (C) 2004-2010
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a>
    <br /> 
    Powered by 
    <a href="/prog/View/doku/info/contr" class="copyright">BDG programozás szakkör</a> &amp;
    <a href="/prog/View/doku/info/njcms" class="copyright">njcms</a>

    v0.5.12
    
        <br /><br />
        <a href="http://validator.w3.org/check?uri=referer">
            <img src="/prog/img/valid-xhtml10-blue.png" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
        </a>
        <a href="http://jigsaw.w3.org/css-validator/check/referer">
            <img style="border: 0pt none ; width: 88px; height: 31px;" src="/prog/img/valid-css-blue.png" alt="Valid CSS!" />
        </a>
        <br />
     
    
    
    <br /><br />


</div>
                </div>
            
        

    </body>
</html>
